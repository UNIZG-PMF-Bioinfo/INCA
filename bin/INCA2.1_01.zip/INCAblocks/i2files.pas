//******************************************************************************
// INCAblocks 2.1, release date 09-Feb-2006
// Maintained by: Fran Supek <fran.supek[at]gmail.com>
// INCAblocks may be copied and modified freely, but give credit where it's due
// Full version of INCA software can be found at http://bioinfo.hr/inca 
// *****************************************************************************

unit i2files;

interface

uses
  SysUtils, Types, Classes, math, i2code, i2genes{$IFDEF INCA_FULL}, QForms{$ENDIF};

procedure ParseENT(AGL: TGeneList; ParamFileName: string;
  Warnings: TStringList; LengthCutoff, WarnToler: Integer; StoreSeqs: boolean);
procedure ParseFFN(AGL: TGeneList; ParamFileName: string; Warnings: TStringList;
  LengthCutoff, WarnToler: Integer; StoreSeqs: boolean);
procedure ParsePTT(AGL: TGeneList; ParamFileName: string; Warnings: TStringList;
  LengthCutoff: integer);
procedure ParseProteinFasta(AGL: TGeneList; ParamFileName: string;
  Warnings: TStringList; LengthCutoff, WarnToler: Integer);

function LoadUserFreq(FileName: string):TCodonFreq;
procedure SaveFreq(Filename: string; ACF: TCodonFreq);

procedure SaveFFN(AGL:TGeneList; FileName:string; HeaderFormat:string);

implementation

{$IFDEF INCA_FULL}uses Unit1;{$ENDIF}

procedure ParseENT(AGL: TGeneList; ParamFileName: string;
  Warnings: TStringList; LengthCutoff, WarnToler: Integer; StoreSeqs: boolean);
var
  TF: TextFile;
  Line, Field, FieldName, ts, Seq, NumStr: String;
  AGene: TGene;
  i, TooShortCount, DotsPos, n, CutFrom, CutTo, cnt, GeneStart, GeneEnd: Integer;
  GeneOK: boolean;
  posCDS: integer;
begin
  if not FileExists(ParamFileName) then Exit;
  AssignFile(TF, ParamFileName); Reset(TF);
  Field:=''; Line:=''; FieldName:='';
  AGL.IgnoredCnt:=0; TooShortCount:=0;
  AGL.FileName:=ParamFileName;
  AGene:=TGene.Create; AGL.Add(AGene); GeneOK:=False;

  cnt:=0;
  while not Eof(TF) do begin

    Readln(TF, Line); inc(cnt);
    {$IFDEF INCA_FULL}Application.ProcessMessages;
    if (cnt mod 1000=0) and Assigned(AGL.StatusBar) then begin
      AGL.StatusBar.SimpleText:='Parsing file '+ExtractFileName(ParamFileName)+'. '+
      IntToStr( AGL.Count )+' genes read.'; Application.ProcessMessages;
    end;
    {$ENDIF}

    if Copy(Line, 1, 1)=' ' then begin

      if FieldName<>'NTSEQ' then Field:=Field+' '+Trim(Line)
        else Field:=Field+Trim(Line);

    end else begin
          // <------ done with the current field (if any) and starting a new one

      if (FieldName='///') (*or (cnt=TF.Count)*) then begin  // <--- done with current gene

        GeneOK:=True;
        if StoreSeqs then AGene.Sequence:=Seq;

        //now perform some checks and issue warnings if necessary
        if (Length(Seq) mod 3)>0 then begin
          if Assigned(Warnings) then
            Warnings.Add(Format('Gene %s (%s) has a sequence whose length '
              +'is not divisible by 3.', [AGene.Name, AGene.Synonym]));
          Inc(AGene.WarnCount);
        end;

        i:=AGene.AminoCount['X']; //checking the stop codons
        if Seq<>'' then begin
          ts:=copy(Seq, Length(Seq)-2, 3);  //the final codon
          i:=i-Integer(iCode.Table[CodonOrd(ts)]='X');
        end else
          i:=i-1;
        if i>0 then begin
          if Assigned(Warnings) then
            Warnings.Add(Format('Gene %s (%s) has %d internal stop codons.',
              [AGene.Name, AGene.Synonym, i]));
          Inc(AGene.WarnCount, i);
        end;
        if ((Seq<>'') and (iCode.Table[CodonOrd(ts)]<>'X')) or
          ((Seq='') and (i<-1)) then begin //!!!! maybe use 0?
          if Assigned(Warnings) then
            Warnings.Add(Format('Gene %s (%s) is not terminated by a stop '
              +'codon.', [AGene.Name, AGene.Synonym]));
          Inc(AGene.WarnCount);
        end;

        if (WarnToler>-1) and (AGene.WarnCount>WarnToler) then begin
          if Assigned(Warnings) then
            Warnings.Add(Format('==> Gene %s (%s) has been'
              +' discarded (warnings).',
              [AGene.Name, AGene.Synonym]));
          GeneOK:=False;
        end else if (Length(Seq) div 3)<LengthCutoff then begin
          Inc(TooShortCount);
          GeneOK:=False;
        end;

        if not GeneOK then begin
          AGene.Free;
          inc(AGL.IgnoredCnt);
        end;
        AGene:=TGene.Create;
        AGL.Add(AGene);
        GeneOK:=False;
      end else if FieldName='ENTRY' then begin
        posCDS:=Pos('CDS', Field);
        if posCDS=0 then posCDS:=Pos('RNA', Field);
        AGene.Organism:=Trim( Copy(Field, posCDS + 3, Length(Field) - posCDS - 2 ) );
        AGL.Organism:=AGene.Organism;
        AGene.Name:=Copy(Field, 1, Pos(' ', Field)-1);
        AGene.Synonym:=Copy(Field, 1, Pos(' ', Field)-1);
      end else if FieldName='NAME' then begin
        AGene.Name:=Trim(Field);
      end else if FieldName='DEFINITION' then begin
        AGene.Description:=Trim(Field);
      end else if FieldName='POSITION' then begin

        if Pos('complement', Lowercase(ts))>0 then begin
          AGene.Strand:='-';
        end else begin
          AGene.Strand:='+';
        end;

        AGene.LocationStart:=High(Integer);
        AGene.LocationEnd:=0;
        ts:='';
        for n:=1 to system.Length(Field) do
          if (Field[n]<>'>') and (Field[n]<>'>') then ts:=ts+Field[n];

        while Pos('..',ts)>0 do begin
          DotsPos:=Pos('..',ts); CutFrom:=1; CutTo:=system.Length(ts);
          NumStr:='';
          for n:=DotsPos-1 downto 1 do
            if Pos(ts[n], '0123456789')>0 then NumStr:=ts[n]+NumStr else Break;
          if NumStr<>'' then begin
            if StrToInt(numstr)<AGene.LocationStart then AGene.LocationStart:=StrToInt(numstr);
            if StrToInt(numstr)>AGene.LocationEnd then AGene.LocationEnd:=StrToInt(numstr);
          end;
          NumStr:='';
          for n:=DotsPos+2 to system.Length(ts) do
            if Pos(ts[n], '0123456789')>0 then NumStr:=NumStr+ts[n] else begin
              CutTo:=n;
              Break;
            end;
          if NumStr<>'' then begin
            if StrToInt(numstr)<AGene.LocationStart then AGene.LocationStart:=StrToInt(numstr);
            if StrToInt(numstr)>AGene.LocationEnd then AGene.LocationEnd:=StrToInt(numstr);
          end;
          Delete(ts, CutFrom, CutTo-CutFrom);
        end;

      end else if (FieldName='DBLINKS') then begin

        Field:=Field+' ';
        if (pos('NCBI-GI', Field)>0) then begin
          ts:=Copy(Field, Pos('NCBI-GI: ',Field)+9,
            Length(Field)-Pos('NCBI-GI: ',Field)-8);
          AGene.NCBI_GI:=StrToInt( Copy( ts, 1, Pos(' ',ts)-1 ) );
        end;
        if (pos('NCBI-GeneID', Field)>0) then begin
          ts:=Copy(Field, Pos('NCBI-GeneID: ',Field)+13,
            Length(Field)-Pos('NCBI-GeneID: ',Field)-12);
          AGene.NCBI_GeneID:=StrToInt( Copy( ts, 1, Pos(' ',ts)-1 ) );
        end;
        if (pos('UniProt', Field)>0) then begin
          ts:=Copy(Field, Pos('UniProt: ',Field)+9,
            Length(Field)-Pos('UniProt: ',Field)-8);
          AGene.UniProt:=Copy( ts, 1, Pos(' ',ts)-1 );
        end;

      end else if FieldName='NTSEQ' then begin
        i:=1;
        while not (Field[i] in ['a','g','c','t','A','G','C','T']) do inc(i);
        Seq:=UpperCase(Copy(Field, i, Length(Field)-i+1));
        AGene.Calculate(Seq);

      end;

      //new field!

      if Pos(' ', Line)=0 then begin
        FieldName:=Line;
        Field:='';
      end else begin
        FieldName:=Copy(Line, 1, Pos(' ',Line)-1);
        Field:=Trim(Copy(Line,Pos(' ',Line),Length(Line)-Pos(' ',Line)+1))+' ';
      end;

    end;

  end;

  AGL.Calculate;
  if (not GeneOK) or (AGL.IndexOf(AGene)=-1) or (AGene.EffectiveCodons=0) then AGene.Free;
  if (TooShortCount>0) and Assigned(Warnings) then
    Warnings.Add('<font color=#770000>'+
    'A total of '+IntToStr(TooShortCount)+' genes were ignored based on the '+
    'length criterion (shorter than '+IntToStr(LengthCutoff)+
    ' codons).</font>');

  {$IFDEF INCA_FULL}if Assigned(AGL.StatusBar) then AGL.StatusBar.SimpleText:='';{$ENDIF}

end;



//******************************************************************************

procedure ParsePTT(AGL: TGeneList; ParamFileName: string;
  Warnings: TStringList; LengthCutoff: Integer);
var
  ASl:TStringList; AGene:TGene;
  n, m, nn, mm, p, PosStart, PosEnd:integer;
  Line:string;
  kol:TPttColumns; ts:string;
  FirstFile: Boolean; //is this the first file parsed?
begin
  n:=0;
  if AGL.Count=0 then FirstFile:=True else FirstFile:=False;
  ASl:=TStringList.Create;
  try try
    AGene:=nil;
    ASl.LoadFromFile(ParamFileName);
    if asl[0]='' then ts:=asl[1] else ts:=asl[0];

    //extract organism name from that line
    ts:=Trim(ts); m:=pos(' ',ts); n:=pos(' ',Copy(ts,m+1,Length(ts)-m))+m;
    p:=pos(',',Copy(ts,m+1,Length(ts)-m))+m; m:=Min(n,p); ts:=Copy(ts,1,m-1);

    if AGL.Organism='' then AGL.Organism:=ts; //if field empty, store org name there

    for n:=0 to asl.Count-1 do begin  //go through lines of the .ptt file

      Line:=asl[n];

      {$IFDEF INCA_FULL}Application.ProcessMessages;
      if (n mod 100=0) and Assigned(AGL.StatusBar) then begin
        AGL.StatusBar.SimpleText:='Parsing file '+ExtractFileName(ParamFileName)+'. '+
        IntToStr(Trunc(n/asl.Count*100))+'% done.'; Application.ProcessMessages;
      end;{$ENDIF}
      
      //skip header lines in file
      if (pos('..',Line)=0) or (pos(#9,Line)=0) then Continue;

      {split the line into columns, if the line contains less then 8 or more
       than 10 tabs, raise an exception; also do so in case some of these
       fields contain invalid values ie. nonnumerical gene start/end...}
      Line:=Line+#9;
      nn:=0; mm:=Pos(#9,Line);
      While mm>0 do begin
        inc(nn); if nn>10 then
          Raise EfsInvalidFile.Create('');
        kol[nn]:=Trim(copy(Line,1,mm));
        Line:=Copy(Line,mm+1,Length(Line)-mm);
        mm:=Pos(#9,Line);
      end;
      if nn<8 then Raise EfsInvalidFile.Create('');

      PosStart:=StrToInt(Trim(copy(kol[1],1,pos('..',kol[1])-1)));
      PosEnd:=StrToInt(Trim(copy(kol[1],pos('..',kol[1])+2,9)));
      AGene:=nil;

      //if Abs(PosStart-PosEnd)<LengthCutoff then Continue;

      if not FirstFile then begin //..search the genome for match
        for m:=0 to AGL.Count-1 do
          if (AGL[m].LocationStart=PosStart) and
          (AGL[m].LocationEnd=PosEnd) then begin //found it!
            AGene:=AGL[m]; Break;
          end;
      end;

      //not found->next line
      if AGene=nil then Continue;
      //not found->create new
      //if AGene=nil then begin AGene:=TGene.Create; self.Add(AGene); end;
      AGene.LocationStart:=PosStart;
      AGene.LocationEnd:=PosEnd;
      AGene.Name:=kol[5];
      AGene.NCBI_GI:=StrToInt(kol[4]);
      //AGene.Length:=StrToInt(kol[3]);
      AGene.Description:=kol[9]; AGene.Synonym:=kol[6];
      AGene.TrueInfo:=True;

      if (AGene.LocationStart>AGene.LocationEnd) then
        Raise EfsInvalidFile.Create('');

      if (kol[2]='') or (kol[7]='') then Raise EfsInvalidFile.Create('');
      AGene.Strand:=(kol[2])[1];
      if system.Length(kol[7])>0 then AGene.COG:=(kol[7])[1] else AGene.COG:='-';
      if pos(AGene.COG, COGs)>1 then AGene.Member[i2CogCat]:=pos(AGene.COG, COGs)-1;

      if (AGene.Strand<>'+') and (AGene.Strand<>'-') then
        //Raise EfsInvalidFile.Create('');
        AGene.Strand:='?';

      AGene.SuperCat:=SuperCats[pos(AGene.COG,COGs)];
    end; //for n, goes through all the lines in the ptt file

  except
    {all other exceptions (index out of range, strtoint errors, manually raised
     cause an EfsInvalidFile to be raised, and the current TGene freed;}
    if Assigned(AGene) then AGene.Free;
    if Assigned(Warnings) then
      Warnings.Add( Format('File %s appears to be corrupted and '
        +'contains invalid data at line %d. The file will not be examined '
        +'further.', [ExtractFileName(ParamFileName), n+1]) );
  end
  finally
    ASl.Free;

    {$IFDEF INCA_FULL}
    if Assigned(AGL.StatusBar) then AGL.StatusBar.SimpleText:='';
    {$ENDIF}

  end; //if .ptt, try...
end;


procedure ParseFFN(AGL: TGeneList; ParamFileName: string;
  Warnings: TStringList; LengthCutoff, WarnToler: Integer; StoreSeqs: Boolean);
var
  ASl:TStringList; Line, Seq, Num, GName, GDesc: string; n,m,p,nn,mto:integer;
  PosStart, PosEnd: integer; AGene:TGene; Comma: integer; ts:string;
  IsNumber: Boolean; FirstFile:boolean;
  TooShortCount: Integer;
  q: Byte; ACC: TCodonCount; ValCode, SpacePos, SeqLen: Integer;
  TF: TextFile;
begin
  TooShortCount:=0;
  ASl:=TStringList.Create;
  if AGL.Count=0 then FirstFile:=True else FirstFile:=False;

  try
    AssignFile(TF, ParamFileName); Reset(TF);
    //ASl.LoadFromFile(ParamFileName); -> Changed in INCA 2.1

    AGL.Filename:=ParamFileName;
    Seq:=''; Num:='0'; PosStart:=High(Integer); PosEnd:=0; GName:=''; GDesc:='';
    SeqLen:=0;

    while not Eof(TF) do begin  //one more iteration than the number of lines in file!

      {$IFDEF INCA_FULL}
      Application.ProcessMessages;
      if (n mod 100=0) and Assigned(AGL.StatusBar) then begin
        AGL.StatusBar.SimpleText:='Parsing file '+ExtractFileName(ParamFileName)+'. '+
        IntToStr(AGL.Count)+' genes read.'; Application.ProcessMessages;
      end;
      {$ENDIF}

      Readln(TF, Line); if Line='' then Continue;  //skip empty lines


      if Line[1]<>'>' then begin //if line doesn't start with '>'

        Line:=UpperCase(Line);
        if (pos(' ', Line)=0) (*and (Line[1] in Ambiguities)*) then begin
          Seq:=Seq+Line;  //FASTA formatted file
          SeqLen:=system.Length(Seq);
        end else begin //cutg codon counts formatted file
          SeqLen:=0;
          for q:=0 to 63 do begin
            if q=63 then SpacePos:=system.Length(Line)+1
              else SpacePos:=Pos(' ',Line);
            Val( Copy( Line,1,SpacePos-1 ), ACC[cutgToCodon(q)], ValCode );
            if ValCode>0 then ACC[cutgToCodon(q)]:=0;
            SeqLen:=SeqLen+ACC[cutgToCodon(q)]*3;
            Line:=Copy( Line, SpacePos+1,
              system.Length(Line)-SpacePos );
          end;
        end;

      end;


      //if we're done with the current gene (and we actually read something -> SeqLen>0)
      //or we're past last line in the file
      if Eof(TF) or ((Copy(Line,1,1)='>') and (SeqLen>0)) then begin

        if (SeqLen div 3)>=LengthCutoff then begin
          if PosEnd>PosStart then begin  //if positions are ok...
            AGene:=nil;
            if not FirstFile then begin
              for p:=0 to AGL.Count-1 do //...search the genome
                if (AGL[p].LocationStart=PosStart) and
                (AGL[p].LocationEnd=PosEnd) then begin //found it!
                  AGene:=AGL[p]; Break;
                end;
            end; //if not firstfile
            if AGene=nil then begin //couldn't find it, create new
              AGene:=TGene.Create;
              AGene.LocationStart:=PosStart; AGene.LocationEnd:=PosEnd;
            end
          end else begin  //if positions are not ok, just create new
            AGene:=TGene.Create;
          end;  //if pos

          if Seq<>'' then begin
            if StoreSeqs then AGene.Sequence:=Seq;
            AGene.Calculate(Seq)
          end
            else AGene.Calculate(ACC); //this is CUTG-formatted codon counts file

          AGene.Length:=SeqLen;
          if AGene.COG=#0 then AGene.COG:='-';
          if AGene.Strand=#0 then AGene.Strand:='?';
          if AGene.Name='' then AGene.Name:=GName;
          if AGene.Description='' then AGene.Description:=GDesc;
          if AGene.Synonym='' then AGene.Synonym:=Format('%.4d',
            [AGL.Count+1]);
          //now perform some checks and issue warnings if necessary
          if (System.Length(Seq) mod 3)>0 then begin
            if Assigned(Warnings) then
              Warnings.Add(Format('Gene %s (%s) has a sequence whose length '
                +'is not divisible by 3.', [AGene.Name, AGene.Synonym]));
            Inc(AGene.WarnCount);
          end;

          nn:=AGene.AminoCount['X'];
          if Seq<>'' then begin
            ts:=copy(Seq, System.Length(Seq)-2, 3);  //the final codon
            nn:=nn-Integer(iCode.Table[CodonOrd(ts)]='X');
          end else
            nn:=nn-1;
          if nn>0 then begin
            if Assigned(Warnings) then
              Warnings.Add(Format('Gene %s (%s) has %d internal stop codons.',
                [AGene.Name, AGene.Synonym, nn]));
            Inc(AGene.WarnCount, nn);
          end;
          if ((Seq<>'') and (iCode.Table[CodonOrd(ts)]<>'X')) or
            ((Seq='') and (nn<-1)) then begin //!!!! return to 0
            if Assigned(Warnings) then
              Warnings.Add(Format('Gene %s (%s) is not terminated by a stop '
                +'codon.', [AGene.Name, AGene.Synonym]));
            Inc(AGene.WarnCount);
          end;
          if (WarnToler>-1) and (AGene.WarnCount>WarnToler) then begin
            Inc(AGL.IgnoredCnt);
            if Assigned(Warnings) then
              Warnings.Add(Format('<font color=#770000>Gene %s (%s) has been'
                +' discarded (warnings).</font>', [AGene.Name, AGene.Synonym]));
            AGene.Free;
          end else
            AGL.Add(AGene);
          //if not Added or Freed, Gene will remain in Genome zero -> bad!
        end else begin
          Inc(AGL.IgnoredCnt); Inc(TooShortCount);
        end; //if Length>Cutoff

        //if AGene.COG=#0 then AGene.COG:='-';

        Seq:=''; for q:=0 to 63 do ACC[q]:=0; SeqLen:=0;

        PosStart:=High(Integer); PosEnd:=0;

      end;


      if Line[1]='>' then begin  //if it's a comment line

        Comma:=Pos(',',Line);
        if (Comma>0) and (Comma<pos(':',Line)) then begin
          GName:=Copy(Line,2,Comma-2);
          GDesc:=Copy(Line, Comma+1, Length(Line)-Comma);
        end else begin
          GDesc:=Copy(Line,2,Length(Line)-1);
          GName:=Copy(GDesc,1,Min(Length(GDesc),7));
        end;
        Line:=Copy(Line, Comma+1, Length(Line)-Comma);

        m:=Pos(':', Line);  //look for numbers only after the colon (if exists)
        mto:=Pos(')', Line); //up to the right parenthesis
        //if mto=0 then mto:=Pos(',', Line);
        if mto=0 then mto:=Length(Line);

        while m<mto do begin
          inc(m); IsNumber:=(Line[m] in ['0'..'9']);
          if IsNumber then Num:=Num+Line[m];
          if ((not IsNumber) or (m=mto)) and (Length(Num)>1) then begin
            p:=StrToInt(Num); Num:='0';
            if p<PosStart then PosStart:=p; //store smallest in posstart...
            if p>PosEnd then PosEnd:=p;  //...and biggest in posend
          end;
        end;
        //if positions aren't specified, or there is something wrong with them
        if PosStart>PosEnd then PosStart:=PosEnd;

      end;





    end; //---------------------------------------> while not EoF(TS) do begin...

    if TooShortCount>0 then
      if Assigned(Warnings) then
        Warnings.Add('<font color=#770000>'+
        'A total of '+IntToStr(TooShortCount)+' genes were ignored based on the '+
        'length criterion (shorter than '+IntToStr(LengthCutoff)+
        ' codons).</font>');

  finally

    AGL.Calculate;
    ASl.Free;
    {$IFDEF INCA_FULL}
    if Assigned(AGL.StatusBar) then AGL.StatusBar.SimpleText:='';
    {$ENDIF}

  end;  //try

end;



procedure ParseProteinFasta(AGL: TGeneList; ParamFileName: string;
  Warnings: TStringList; LengthCutoff, WarnToler: Integer);
var
  ASl: TStringList;
  Line, Seq, Num, GName, GDesc, GSyn, GScopStr: string;
  n, m, p, nn, mto, pGI, GGI: integer;
  PosStart, PosEnd: integer;
  AGene: TGene;
  Comma: integer;
  ts:string;
  IsNumber: Boolean; FirstFile:boolean;
  TooShortCount: Integer;
  q: Byte; ACC: TCodonCount; ValCode, SpacePos, SeqLen: Integer;
  TPs, TNs: Integer;
begin
  TooShortCount:=0;
  ASl:=TStringList.Create;
  if AGL.Count=0 then FirstFile:=True else FirstFile:=False;
  SeqLen:=0;
  try
    ASl.LoadFromFile(ParamFileName); AGL.Filename:=ExtractFileName(ParamFileName);
    Seq:=''; Num:='0'; PosStart:=High(Integer); PosEnd:=0; GName:=''; GDesc:='';
    for n:=0 to ASl.Count do begin  //one more than the number of lines in file!

      {$IFDEF INCA_FULL}
      Application.ProcessMessages;
      if (n mod 100=0) and Assigned(AGL.StatusBar) then begin
        AGL.StatusBar.SimpleText:='Parsing file '+ExtractFileName(ParamFileName)+'. '+
        IntToStr(Trunc(n/asl.Count*100))+'% done.'; Application.ProcessMessages;
      end;
      {$ENDIF}

      //if we're done with the current gene or we're past last line in the file
      if (n=asl.Count) or ((Copy(Asl[n],1,1)='>') and (SeqLen>0)) then begin
        if (*SeqLen>=LengthCutoff*) True then begin
          AGene:=TGene.Create;
          AGene.Translation:=Seq;
          AGene.Sequence:='';
          AGene.Length:=SeqLen;
          AGene.COG:='-'; AGene.Strand:='?';
          AGene.Name:=GName; AGene.Synonym:=GSyn; AGene.NCBI_GI:=GGI;
          AGene.Description:=GDesc;
          if AGene.Synonym='' then AGene.Synonym:=Format('%.4d', [AGL.Count+1]);

          m:=0;
          while (pos('.', GScopStr)>0) and (m<=High(AGene.SCOP)) do begin
            if GScopStr[1] in ['a'..'z'] then AGene.SCOP[m]:=Ord(GScopStr[1])-96
              else AGene.SCOP[m]:=StrToInt( Copy(GScopStr,1,Pos('.',GScopStr)-1) );
            GScopStr:=Copy(GScopStr, Pos('.',GScopStr)+1, Length(GScopStr)-Pos('.',GScopStr));
            inc(m);
          end;


          AGL.Add(AGene);
          //if not Added or Freed, Gene will remain in Genome zero -> bad!
        end else begin
          Inc(AGL.IgnoredCnt); Inc(TooShortCount);
        end; //if Length>Cutoff

        Seq:=''; for q:=0 to 63 do ACC[q]:=0; SeqLen:=0;

        PosStart:=High(Integer); PosEnd:=0;
        if n=asl.Count then Break;
        //we have to Break loop before the "line" after the last can be examined
      end;

      Line:=ASl[n];
      if Line='' then Continue;  //skip empty lines

      if Line[1]='>' then begin  //if it's a comment line

        pGI:=Pos('gi|',Line);
        if pGI>0 then begin
          pGI := pGI + 3;
          ts:='';
          while (pGI<=Length(Line)) and (Line[pGI] in ['0','1','2','3','4','5','6','7','8','9'])
            do begin ts:=ts+Line[pGI]; Inc(pGI); end;
          GGI:=0;
          Val(ts, GGI, pGI);
        end;

        GName:=Trim(Copy(Line,2,10));
        GDesc:=ExtractFileName(ParamFileName)+'_'+StringReplace(Trim(Copy(Line,2,Length(Line)-1)), '"', '', [rfReplaceAll]);

        if ExtractFileExt(ParamFileName)='.astral' then begin
          GScopStr:=Copy(Line, Pos(' ', Line)+1, Length(Line));
          GSyn:=GScopStr;
          GScopStr:=Copy(GScopStr, 1, Pos(' ', GScopStr)-1)+'.';
          GName:=Copy(Line, 2, Pos(' ', Line)-2);
        end else begin
          Line:=Copy(Line, 11, system.Length(Line)-10);
          Comma:=Pos(' ',Line);
          if (Comma>0) and (Comma<pos('(',Line)) then begin
            GSyn:=Copy(Line,1,Comma-1);
            //GDesc:=Copy(Line, Comma+1, Length(Line)-Comma);
          end else begin
            GSyn:='';
            //GDesc:=Copy(Line,1,Length(Line)-1);
          end;
        end;



        PosStart:=0; PosEnd:=0;


      end else begin //if line doesn't start with '>'
        Line:=UpperCase(Line);
        Seq:=Seq+Line;  //FASTA formatted file
        SeqLen:=system.Length(Seq);
      end;

    end; //for n




    if TooShortCount>0 then
      if Assigned(Warnings) then
        Warnings.Add('<font color=#770000>'+
        'A total of '+IntToStr(TooShortCount)+' genes were ignored based on the '+
        'length criterion (shorter than '+IntToStr(LengthCutoff)+
        ' codons).</font>');


  finally
    //AGL.Calculate;
    ASl.Free;
    {$IFDEF INCA_FULL}
    if Assigned(AGL.StatusBar) then AGL.StatusBar.SimpleText:='';
    {$ENDIF}
  end;  //try
  
end;



function LoadUserFreq(FileName: string):TCodonFreq;  //load user freq table
const
  OkChars = ['A'..'Z', 'a'..'z', '0'..'9', '.'];
var
  n,m:Integer; ASl:TStringList; AWord,Line:String; Codon:String;
  Freq:Real; ValCode:Integer; q:Byte; c:char; AminoSum: TAminoFreq;
begin
  ASl:=TStringList.Create;
  ASl.LoadFromFile(FileName);
  for n:=0 to 63 do Result[n]:=0;
  for n:=0 to ASl.Count-1 do begin
    Line:=UpperCase(ASl[n]);
    if (Line='') or (Copy(Line,1,1)='>') then Continue;
    Codon:=''; Freq:=-1;
    m:=1;  //position in the current line
    while (m<=Length(Line)) {and ((Codon='') or (Freq=-1))} do begin
      AWord:='';
      while ( m<=Length(Line) ) and
        ( (Line[m] in OkChars) or (Line[m]=DecimalSeparator) )
        do begin
          if Line[m]=DecimalSeparator then AWord:=AWord+'.'
            else AWord:=AWord+Line[m];
          inc(m);
        end;
      if (Length(AWord)=3) and (AWord[1] in Nucleotides) and
        (AWord[2] in Nucleotides) and (AWord[3] in Nucleotides) then begin
        Codon:=AWord; Freq:=-1; Continue;
      end;
      Val(AWord, Freq, ValCode);
      if ValCode=0 then //value found! no error
        if (Codon<>'') and (Freq>-1) then begin //if both codon and value found
          Result[CodonOrd(Codon)]:=Freq; //assign
          Codon:=''; Freq:=-1;
        end;
      inc(m);
    end;
  end;
  ASl.Free;
  //now normalize values
  for c:=low(AminoSum) to high(AminoSum) do AminoSum[c]:=0;
  for q:=0 to 63 do
    AminoSum[iCode.Table[q]]:=AminoSum[iCode.Table[q]] + Result[q];
  for q:=0 to 63 do
    Result[q] := Result[q] / AminoSum[iCode.Table[q]];
end;

procedure SaveFreq(Filename: String; ACF: TCodonFreq);  //save frequencies
var
  p,q:Integer; ASl:TStringList; Line:String;
begin
  ASl:=TStringList.Create;

  //header line
  Line:='>Codon'+#9+'Amino'+#9+'Freq';
  ASl.Add(Line);

  //lines with the frequencies
  for p:=0 to 63 do begin
    q:=iCode.SortedCodons[p];
    Line:= CodonChr(q) + #9
      + iCode.Table[q] + ' ' + AminoList[iCode.Table[q]] + #9
      + FloatToStrF(ACF[q], ffFixed, 7, 4);
    ASl.Add(Line);
  end;

  ASl.SaveToFile(FileName); ASl.Free;
end;

procedure SaveFFN(AGL:TGeneList; FileName:string; HeaderFormat: string);
var
  n, m, i: integer;
  tf: TextFile;
  s: string;
  c: Char;
begin
  AssignFile(tf, FileName);
  Rewrite(TF);
  for n:=0 to AGL.Count-1 do begin
    if not AGL[n].Visible then Continue;
    s:='>'+HeaderFormat;
    s:=StringReplace(s, '%NAME%', AGL[n].Name, []);
    s:=StringReplace(s, '%SYNONYM%', AGL[n].Synonym, []);
    s:=StringReplace(s, '%DESCRIPTION%', AGL[n].Description, []);
    if AGL[n].Checked then c:='T' else c:='F';
    s:=StringReplace(s, '%ISCHECKED%', c, []);
    s:=StringReplace(s, '%WARNCOUNT%', IntToStr(AGL[n].WarnCount), []);
    s:=StringReplace(s, '%ORGANISM%', AGL[n].Organism, []);
    s:=StringReplace(s, '%LOC_START%', IntToStr(AGL[n].LocationStart), []);
    s:=StringReplace(s, '%LOC_END%', IntToStr(AGL[n].LocationEnd), []);
    s:=StringReplace(s, '%NCBI_GI%', IntToStr(AGL[n].NCBI_GI), []);
    s:=StringReplace(s, '%NCBI_GENEID%', IntToStr(AGL[n].NCBI_GeneID), []);
    s:=StringReplace(s, '%COG_CAT%', AGL[n].COG, []);
    s:=StringReplace(s, '%UNIPROT%', AGL[n].UniProt, []);
    s:=StringReplace(s, '%STRAND%', AGL[n].Strand, []);

    {$IFDEF INCA_FULL}
    i:=0;
    for m:=1 to High(Form1.BrowserCols)+1 do begin
      if Form1.BrowserColsChecked[m-1] then Inc(i) else Continue;
      if Pos('%COLUMN'+IntToStr(i)+'%', s)>0 then
        s:=StringReplace(s, '%COLUMN'+IntToStr(i)+'%',
          FloatToStrF(AGL[n].GetProp(Form1.BrowserCols[m-1]), ffGeneral, 7, 5), []);
    end;
    {$ENDIF}


    Writeln(tf, s);
    Writeln(tf, AGL[n].Sequence);

  end;
  CloseFile(TF);
end;


end.
