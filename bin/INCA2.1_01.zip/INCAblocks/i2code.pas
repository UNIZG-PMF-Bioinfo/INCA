//******************************************************************************
// INCAblocks 2.1, release date 09-Feb-2006
// Maintained by: Fran Supek <fran.supek[at]gmail.com>
// INCAblocks may be copied and modified freely, but give credit where it's due
// Full version of INCA software can be found at http://bioinfo.hr/inca 
// *****************************************************************************

unit i2code;

interface

uses
  SysUtils, math, classes;

type
  EGeneticCodeError = class(Exception);

  TAminoFreq = array ['A'..'Z'] of Single;
  TAminoCount = array ['A'..'Z'] of Integer;
  TCodonFreq = array [0..63] of Single;
  TCodonCount = array [0..63] of Integer;
  TCodonW = array [0..63] of Single;  //w values used in calculating CAI
  TCodonFreqAbs = array [0..63] of Single;
  TNuclFreq = array [0..3] of Single;
  TNuclCount = array [0..3] of Integer;
  TCodonSet = set of Byte;
  TFoldCount = array [1..64] of Byte;
  TFoldFreq = array [1..64] of Real;
  TSortedCodons = array [0..63] of Byte;

  TTransTable = array [0..63] of Char;

  TCode = class(TObject)
  private
    FTable: TTransTable; //translation table
    FTableIndex: Byte;
    FNormalCodonFreq: TCodonFreq; //unbiased frequency for each amino
    FAminoFold: TAminoCount; //how many codons code for a single amino
    FnFoldAminos: TFoldCount; //how many n-fold aminos exist in code
    FSilentCodons: TCodonSet; //codons where 3rd pos transition (A>G C>T) silent
    FSortedCodons: TSortedCodons; //codons sorted by amino 1letter abbr.
  protected
    procedure SetTable(ATable: TTransTable);
    procedure SetTableIndex(Index: Byte);
  public
    function NuclToCodonFreq(ANuclFreq: TNuclFreq):TCodonFreq;
    function AminoFreqToP(AAminoFreq: TAminoFreq): TAminoFreq;
    function CodonFreqToP(ACodonFreq: TCodonFreq): TCodonFreq;
    function Codon2SilentNuclFreq(ACodonCount: TCodonCount):TNuclFreq;
    function Translate(const ASeq: string):string;
    function BackTranslate(const ASeq: string):string;
    property Table:TTransTable read FTable write SetTable;
    property TableIndex:Byte read FTableIndex write SetTableIndex;
    property NormalCodonFreq: TCodonFreq read FNormalCodonFreq;
    property AminoFold: TAminoCount read FAminoFold;
    property nFoldAminos: TFoldCount read FnFoldAminos;
    //which codons can have a silent transition (A->G, C->T) at the position 3
    property SilentCodons: TCodonSet read FSilentCodons;
    property SortedCodons: TSortedCodons read FSortedCodons;
  end;


function ReverseComplementary(const input:string):string;
function CodonOrd(const codon:string):ShortInt;
function NuclOrd(c:char):byte;
function CodonChr(i:integer):string;
function Codon2NuclCount(ACodonCount: TCodonCount):TNuclCount;
procedure RNAtoDNA(var seq:string);
function CountCodons(const Aseq:string): TCodonCount;
function cutgOrd(const codon:string):Byte;
function cutgChr(i:integer):string;
function cutgToCodon(i:byte):byte;

const
  {these are the various translation tables; char at position
  n defines what aminoacid is coded by the codon number n - use CodonOrd
  function to translate three-leter string to codon number}

  TransTables: array [1..23] of TTransTable = (
    //1. The Standard Code
      'FFLLSSSSYYXXCCXWLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG',
    //2. The Vertebrate Mitochondrial Code
      'FFLLSSSSYYXXCCWWLLLLPPPPHHQQRRRRIIMMTTTTNNKKSSXXVVVVAAAADDEEGGGG',
    //3. The Yeast Mitochondrial Code
      'FFLLSSSSYYXXCCWWTTTTPPPPHHQQRRRRIIMMTTTTNNKKSSRRVVVVAAAADDEEGGGG',
     {4. The Mold, Protozoan, and Coelenterate Mitochondrial Code
         and the Mycoplasma/Spiroplasma Code}
      'FFLLSSSSYYXXCCWWLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG',
    //5. The Invertebrate Mitochondrial Code
      'FFLLSSSSYYXXCCWWLLLLPPPPHHQQRRRRIIMMTTTTNNKKSSSSVVVVAAAADDEEGGGG',
    //6. The Ciliate, Dasycladacean and Hexamita Nuclear Code
      'FFLLSSSSYYQQCCXWLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG',
    //Tables 7 and 8 are obsolete; replace 7 with 4, and 8 with 1
      '', '',
    //9. The Echinoderm and Flatworm Mitochondrial Code
      'FFLLSSSSYYXXCCWWLLLLPPPPHHQQRRRRIIIMTTTTNNNKSSSSVVVVAAAADDEEGGGG',
    //10. The Euplotid Nuclear Code
      'FFLLSSSSYYXXCCCWLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG',
    //11. The Bacterial and Plant Plastid Code
      'FFLLSSSSYYXXCCXWLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG',
    //12. The Alternative Yeast Nuclear Code
      'FFLLSSSSYYXXCCXWLLLSPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG',
    //13. The Ascidian Mitochondrial Code
      'FFLLSSSSYYXXCCWWLLLLPPPPHHQQRRRRIIMMTTTTNNKKSSGGVVVVAAAADDEEGGGG',
    //14. The Alternative Flatworm Mitochondrial Code
      'FFLLSSSSYYYXCCWWLLLLPPPPHHQQRRRRIIIMTTTTNNNKSSSSVVVVAAAADDEEGGGG',
    //15. Blepharisma Nuclear Code
      'FFLLSSSSYYXQCCXWLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG',
    //16. Chlorophycean Mitochondrial Code
      'FFLLSSSSYYXLCCXWLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG',
    //17-20 don't exist
      '', '', '', '',
    //21. Trematode Mitochondrial Code
      'FFLLSSSSYYXXCCWWLLLLPPPPHHQQRRRRIIIMTTTTNNNKSSSSVVVVAAAADDEEGGGG',
    //22. Scenedesmus obliquus mitochondrial Code
      'FFLLSSXSYYXLCCXWLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG',
    //23. Thraustochytrium Mitochondrial Code
      'FFXLSSSSYYXXCCXWLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG');

  TransTableNames: array [1..23] of string = (
    'Standard Code',
    'Vertebrate Mitochondrial',
    'Yeast Mitochondrial',
    'Mold/Proto/Coel Mitoch & Mycopl.',
    'Invertebrate Mitochondrial',
    'Ciliate Nuclear', '', '',
    'Echinoderm Mitochondrial',
    'Euplotid Nuclear',
    'Bacterial/Plant plastid',
    'Alt. Yeast Nuclear',
    'Ascidian Mitochondrial',
    'Alt. Flatworm Mitochondrial',
    'Blepharisma Nuclear',
    'Chlorophycean Mitochondrial', '', '', '', '',
    'Trematode Mitochondrial',
    'S. obliquus Mitochondrial',
    'Thraustochytrium Mitochondrial');

  Cutg = 'CGA CGC CGG CGU AGA AGG CUA CUC CUG CUU UUA UUG UCA UCC UCG UCU ' +
     'AGC AGU ACA ACC ACG ACU CCA CCC CCG CCU GCA GCC GCG GCU GGA GGC GGG ' +
     'GGU GUA GUC GUG GUU AAA AAG AAC AAU CAA CAG CAC CAU GAA GAG GAC GAU ' +
     'UAC UAU UGC UGU UUC UUU AUA AUC AUU AUG UGG UAA UAG UGA';

  CutgNum: array[0..63] of byte = (
     30, 29, 31, 28, 46, 47, 18, 17, 19, 16, 2, 3, 6, 5, 7, 4, 45, 44, 38,
     37, 39, 36, 22, 21, 23, 20, 54, 53, 55, 52, 62, 61, 63, 60, 50, 49, 51,
     48, 42, 43, 41, 40, 26, 27, 25, 24, 58, 59, 57, 56, 9, 8, 13, 12, 1,
     0, 34, 33, 32, 35, 15, 10, 11, 14);

  HydroScore: array['A'..'Z'] of Single =
    (1.8, 0, 2.5, -3.5, -3.5, 2.8, -0.4, -3.2, 4.5, 0, -3.9, 3.8, 1.9, -3.5, 0,
     -1.6, -3.5, -4.5, -0.8, -0.7, 0, 4.2, -0.9, 0, -1.3, 0);

  Nucleotides = ['A','G','C','U','T'];
  Ambiguities = ['A','G','C','U','T','M','R','W','S','Y','K','V','H','D','B','X','N'];

  AminoList: array['A'..'Z'] of string = (
  'Ala', '', 'Cys', 'Asp', 'Glu', 'Phe', 'Gly', 'His', //A-H
  'Ile', '', 'Lys', 'Leu', 'Met', 'Asn', '', 'Pro', //I-P
  'Gln', 'Arg', 'Ser', 'Thr', '', 'Val', 'Trp', 'Ter', 'Tyr', '' //Q-Z
  );

  COGList: array['-'..'Z'] of string = (
  'Genes not assigned to a COG', '', '', '', '', '',
  '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  'RNA processing and modification',
  'Chromatin structure and dynamics',
  'Energy production and conversion',
  'Cell cycle control, cell division, chromosome partitioning',
  'Amino acid transport and metabolism',
  'Nucleotide transport and metabolism',
  'Carbohydrate transport and metabolism',
  'Coenzyme transport and metabolism',
  'Lipid transport and metabolism',
  'Translation, ribosomal structure and biogenesis',
  'Transcription',
  'Replication, recombination and repair',
  'Cell wall/membrane/envelope biogenesis',
  'Cell motility',
  'Posttranslational modification, protein turnover, chaperones',
  'Inorganic ion transport and metabolism',
  'Secondary metabolites biosynthesis, transport and catabolism',
  'General function prediction only',
  'Function unknown',
  'Signal transduction mechanisms',
  'Intracellular trafficking, secretion, and vesicular transport',
  'Defense mechanisms',
  'Extracellular structures',
  '',
  'Nuclear structure',
  'Cytoskeleton');

  CogColors:array['-'..'Z'] of integer = (
  $00eeeeee, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, //-
  $00fcdcfc, //A
  $00fcdccc,
  $00bcfcfc,
  $00fcfcdc,
  $00dcfcfc,
  $00dcecfc,
  $00ccfcfc,
  $00dcdcfc,
  $00dcccfc,
  $00fcccfc,
  $00fcdcec,
  $00fcdcdc,
  $00fcdcdc,
  $00dcfcac,
  $009cfcac,
  $00ccccfc,
  $00bcccfc,
  $00e0e0e0,
  $00cccccc,
  $00fcfcac,
  $00acfcac,
  $00fcfcbc,
  $00bcfcac,
  0,
  $00fcfccc,
  $00ccfcac);  //Z

  CogStrongColors:array['-'..'Z'] of integer = (
  $00ffffff, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, //-
  $00FA7DFA, //A
  $00E56832,
  $0036D9D9,
  $00FAFACD,
  $00A0FAFA,
  $00A0CDFA,
  $0065EBEB, //G
  $00A0A0FA,
  $009B6BFA,
  $00E535E5,
  $00FAAFD4,
  $00FA7D7D, //L
  $00CBFA11, //M
  $009DFA11, //N
  $0000BD1C, //O
  $006B6BFA, //P
  $003E6DFA, //Q
  $00e0e0e0, //R
  $00cccccc, //S
  $00EBEB13, //T
  $000ECC0E,
  $00FAFA6B,
  $003CDB0F, //W
  0,
  $00FFFFA6,
  $0068EB10);//Z

  SuperCatList: array['-'..'Z'] of string = ('- Not assigned', '', '', '', '',
    '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
    '', '', '', '', '', '', '', '', 'Information', '', '', '', 'Metabolism',
    '', '', 'Processes', '', '', '', '', 'Unknown', '', '', '', '', '');

  SuperCatListLong: array['-'..'Z'] of string = (
    'Genes not assigned to a COG', '', '', '', '',
    '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
    '', '', '', '', '', '', '', '', 'Information storage and processing',
    '', '', '', 'Metabolism',
    '', '', 'Cellular processes and signaling', '', '', '', '',
    'Poorly characterized', '', '', '', '', '');

  COGs       = '-JAKLBDYVTMNZWUOCGEFHIPQRS';
  SuperCats  = '-IIIIIPPPPPPPPPPMMMMMMMMUU';
  SuperCatsC = '-IPMU';


implementation


procedure TCode.SetTable(ATable: TTransTable);
var
  c:Char; n,m,r,p,s:integer; ts:string; q:byte;
begin
  FTable:=ATable;
  FTableIndex:=0; //0 for user-defined tables; other values for predefined tbls

  //compute the list of codons sorted by aminoacid 1-letter abbreviations
  m:=0;
  for c:='A' to 'Z' do
    for q:=0 to 63 do
      if Table[q]=c then begin
        FSortedCodons[m]:=q; inc(m);
      end;

  //compute normal (unbiased) codon frequencies, how many codons code for a
  //single amino (degeneracy) and count of n-fold degenerate aminos for each n
  r:=0; q:=0;
  for n:=1 to 64 do FnFoldAminos[n]:=0;

  for n:=0 to 63 do begin
    p:=FSortedCodons[n];
    if n<63 then q:=FSortedCodons[n+1];
    inc(r);
    if (Table[p]<>Table[q]) or (n=63) then begin
      for s:=n-r+1 to n do FNormalCodonFreq[FSortedCodons[s]]:=1/r;
      FAminoFold[Table[p]]:=r;
      if (r>0) and (Table[p]<>'X') then Inc(FnFoldAminos[r]);
      r:=0;
    end;
  end;

  //fill the set of codons with silent mutations at pos.3
  FSilentCodons:=[];
  for q:=0 to 63 do begin
    ts:=CodonChr(q);
    if ( Table[CodonOrd(Copy(ts,1,2)+'A')]=Table[q] ) and
       ( Table[CodonOrd(Copy(ts,1,2)+'G')]=Table[q] ) and
       ( Table[CodonOrd(Copy(ts,1,2)+'U')]=Table[q] ) and
       ( Table[CodonOrd(Copy(ts,1,2)+'C')]=Table[q] )
      //this is a codon where 3rd base mutations are silent
      then
        FSilentCodons:=FSilentCodons + [ q ];
  end;

end;


procedure TCode.SetTableIndex(Index:Byte);
begin
  case Index of
    7: Table:=TransTables[4];
    8: Table:=TransTables[1];
    1..6, 9..16, 21..23: Table:=TransTables[Index];
  else
    raise EGeneticCodeError.Create('Translation table nonexistant or not supported.');
  end;
  FTableIndex:=Index;
end;


function ReverseComplementary(const input:string):string;
var
  n:integer;
begin
  Result:='';
  for n:=length(input) downto 1 do
    case input[n] of
      'A': Result:=Result+'T';
      'G': Result:=Result+'C';
      'C': Result:=Result+'G';
      'T': Result:=Result+'A';
    end;
end;


function CodonOrd(const codon:string):ShortInt;
  //returns an index of the codon (0..63)
var
  p:integer;
begin
  Result:=0;
  for p:=1 to 3 do begin
    case codon[p] of
      'T','U': Result:=Result+0*Round(Power(4,(3-p)));
      'C': Result:=Result+1*Round(Power(4,(3-p)));
      'A': Result:=Result+2*Round(Power(4,(3-p)));
      'G': Result:=Result+3*Round(Power(4,(3-p)));
    else
      Result:=-64;  //a signal for invalid nucleotides
    end;
  end;
end;


function CodonChr(i:integer):string;
  //returns a codon (RNA!); takes index as parameter
var
  p:integer;
begin
  Result:='';
  for p:=2 downto 0 do begin
    case (i div Round(Power(4,p))) of
      0: Result:=Result+'U';
      1: Result:=Result+'C';
      2: Result:=Result+'A';
      3: Result:=Result+'G';
    end;
    i:=i mod Round(Power(4,p));
  end;
end;


function cutgOrd(const codon:string):Byte;
var n:integer;
begin
  n:=Pos(codon, cutg);
  Result:=(n-1) div 4;
end;


function cutgChr(i:integer):string;
begin
  Result:=Copy(cutg, i*4+1, 3);
end;


function cutgToCodon(i:byte):byte;
begin
  Result:=cutgNum[i];
end;


function NuclOrd(c:char):byte;
begin
  case c of
    'U','T': Result:=0;
    'C': Result:=1;
    'A': Result:=2;
    'G': Result:=3;
  end;
end;


function Codon2NuclCount(ACodonCount: TCodonCount):TNuclCount;
var
  q,i,p: Byte;
begin
  for q:=0 to 3 do
    Result[q]:=0;

  for q:=0 to 63 do begin
    i:=q;
    for p:=2 downto 0 do begin
      inc( Result[i div Round(Power(4,p))], ACodonCount[q] );
      i:=i mod Round(Power(4,p));
    end;
  end;
end;


function TCode.Codon2SilentNuclFreq(ACodonCount: TCodonCount):TNuclFreq;
var
  q,i,p: Byte; tt: Integer;
begin
  for q:=0 to 3 do
    Result[q]:=0;
  tt:=0;

  for q:=0 to 63 do begin
    if not (q in FSilentCodons) then Continue;
    inc(tt, ACodonCount[q]);
    i:=q;
    for p:=2 downto 0 do begin
      if p=0 then Result[i]:=Result[i]+ACodonCount[q];
      i:=i mod Round(Power(4,p));
    end;
  end;

  for q:=0 to 3 do Result[q]:=Result[q]/tt;
end;


function TCode.NuclToCodonFreq(ANuclFreq: TNuclFreq):TCodonFreq;
var
  q,i,p:Byte; c:Char;
  AAFreqSum: TAminoFreq; //used for renormalization purposes
begin

  for c:='A' to 'Z' do
    AAFreqSum[c]:=0;

  for q:=0 to 63 do begin

    Result[q]:=1;
    i:=q;

    for p:=2 downto 0 do begin
      Result[q]:=Result[q] * ANuclFreq[ i div Round(Power(4,p)) ];
      i:=i mod Round(Power(4,p));
    end;

    AAFreqSum[Table[q]] := AAFreqSum[Table[q]] + Result[q];

  end;

  for q:=0 to 63 do
    if AAFreqSum[Table[q]]>0 then
      Result[q]:=Result[q]/AAFreqSum[Table[q]]; //normalize frequencies

end;


function TCode.AminoFreqToP(AAminoFreq: TAminoFreq): TAminoFreq;
var
  c: Char;
  r: Single;
begin
  r:=0;
  for c:=Low(TAminoFreq) to High(TAminoFreq) do
    r:=r+Sqrt(AAminoFreq[c]);
  for c:=Low(TAminoFreq) to High(TAminoFreq) do
    Result[c]:=Sqrt(AAminoFreq[c])/r;
end;


function TCode.CodonFreqToP(ACodonFreq: TCodonFreq): TCodonFreq;
var
  q: Byte;
  c: Char;
  CodonSqrtSum: TAminoFreq;
begin
  for c:=Low(TAminoFreq) to High(TAminoFreq) do
    CodonSqrtSum[c]:=0;
  for q:=0 to 63 do
    CodonSqrtSum[Table[q]]:=CodonSqrtSum[Table[q]]+Sqrt(ACodonFreq[q]);
  for q:=0 to 63 do
    Result[q]:=Sqrt(ACodonFreq[q])/CodonSqrtSum[Table[q]];
end;


function TCode.Translate(const ASeq: string):string;
var
  m: integer; q: byte;
begin
  Result:='';
  m:=1; //current position in the sequence of the gene
  while (m<System.Length(ASeq)) do begin
    q:=CodonOrd(copy(ASeq,m,3));
    m:=m+3;
    Result:=Result+self.FTable[q];
    //q<0 then Result:=Result+'X' else Result:=Result+self.FTable[q];
  end;
end;

function TCode.BackTranslate(const ASeq: string):string;
var
  n: integer; q,p: byte; c: char;
begin

  for n:=1 to Length(ASeq) do begin
    c:=ASeq[n];
    case c of
      'B': Result:=Result+'RAY';
      'Z': Result:=Result+'SAR';
      'X': Result:=Result+'NNN';
    else
      for q:=0 to 63 do
        if self.FTable[q]=c then begin Result:=Result+CodonChr(q); Break; end;
    end;
  end;

end;


procedure RNAtoDNA(var seq:string);
var
  n:integer;
begin
  for n:=1 to Length(seq) do if seq[n]='U' then seq[n]:='T';
end;


function CountCodons(const Aseq:string): TCodonCount;
var
  m: Integer; q: ShortInt;
begin
  for q:=0 to 63 do Result[q]:=0;
  m:=1; //current position in the sequence of the gene
  while (m<System.Length(ASeq)) do begin
    q:=CodonOrd(copy(ASeq,m,3));
    m:=m+3;
    if q<0 then Continue; //skip invalid codons
    inc(Result[q]);
  end;
end;

end.
