// *****************************************************************************
// INCAblocks 2.1, release date 13-Feb-2006
// Maintained by: Fran Supek <fran.supek[at]gmail.com>
// INCAblocks may be copied and modified freely, but give credit where it's due
// Full version of INCA software can be found at http://bioinfo.hr/inca
// *****************************************************************************

// *****************************************************************************
// Example 2: Load the E. coli K12 genome, move all genes named rps and rpl
// (ribosomal proteins) to the reference set, and output to the screen names,
// length, COG category and description of top 20 non-ribosomal protein genes
// sorted by predicted expression (MELP). The genome .ptt and .ffn
// files can be found at:
// ftp://ftp.ncbi.nih.gov/genomes/Bacteria/Escherichia_coli_K12
// *****************************************************************************

program INCAblocks_example2;

{$APPTYPE CONSOLE}

uses
  SysUtils, Classes, Math, i2code, i2genes, i2files;

var
  n: integer;

begin

  INCAblocksInit;

  //when loading NCBI genome files, you first parse the .ffn (FASTA) and then
  //the .ppt that contains information on the genes' protein products

  WriteLn('Please wait, parsing files.');
      
  ParseFFN(AllGenes, '../genomes/NC_000913.ffn', nil, 100, 1, False);
  ParsePTT(AllGenes, '../genomes/NC_000913.ptt', nil, 100);  
  
  WriteLn('Files loaded.'); // 
  WriteLn('AllGenes now contains ' + IntToStr(AllGenes.Count) + ' genes; ' +
    'RefSet now contains ' + IntToStr(RefSet.Count) + ' genes; ' +
    'NonRef now contains ' + IntToStr(NonRef.Count) + ' genes');
  
  for n:=0 to AllGenes.Count-1 do
    //check if the name of the gene starts with 'rps' or 'rpl'
    if (Pos('rps', AllGenes[n].Name)=1) or (Pos('rpl', AllGenes[n].Name)=1) then 
      RefSet.Add(AllGenes[n]); //this will automatically remove it from NonRef

  WriteLn('Search for ribosomal proteins finished.');
  WriteLn('AllGenes now contains ' + IntToStr(AllGenes.Count) + ' genes; ' +
    'RefSet now contains ' + IntToStr(RefSet.Count) + ' genes; ' +
    'NonRef now contains ' + IntToStr(NonRef.Count) + ' genes');

  (* IMPORTANT! after moving genes from one list to another, you have to make a
  call to the Calculate procedure of the TGeneList objects you modified; this
  works out the average codon frequencies for the group. Calling it more often
  than necessary isn't that wasteful since INCAblocks checks if groups have
  been modified since last recalc. You can also use the RecalcAllGeneLists that
  checks all GeneLists for modifications and recalcs as needed. *)
  
  RefSet.Calculate; NonRef.Calculate;
    
  (* the Sort procedure expects an integer encoding of the property by which
  to sort; these are produced by the EncodeProp function
  -> first parameter is the statistic of codon usage (MILC=6, MELP=11...)
     see the PropToString function in i2genes.pas for all possible explanations
  -> second and third describe the 'relative to what' is the MILC score
     -> second is the type of the genelist encoded as Byte (numeric type)
     -> third is the Index ot the genelist 
     -> here we use MetaLists[i2All].Items[0] = AllGenes
  -> fourth is currently not used *)  
     
  NonRef.Sort( - EncodeProp(11, Byte(i2All), 0, 0 ) ); 
  //sort is by default ascending, use a minus sign to change to descending
  
  WriteLn();  //#9 is the Tab character for pretty output
  WriteLn('Name' + #9 + 'Length' + #9 + 'COGCat' + #9 + 'Description');

  //the EffectiveCodons property is gene length
  //global constant 'COGs' contains letters of COG categories arranged
  //in same order as TGeneLists in MetaLists[i2COGcat]
       
  for n:=0 to 19 do
    WriteLn( NonRef[n].Name + #9 
      + IntToStr(NonRef[n].EffectiveCodons) + #9
      + COGs[ NonRef[n].Member[i2CogCat] ] + #9
      + Copy( NonRef[n].Description, 1, 60 )); 
    
end.

