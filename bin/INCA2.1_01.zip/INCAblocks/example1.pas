// *****************************************************************************
// INCAblocks 2.1, release date 13-Feb-2006
// Maintained by: Fran Supek <fran.supek[at]gmail.com>
// INCAblocks may be copied and modified freely, but give credit where it's due
// Full version of INCA software can be found at http://bioinfo.hr/inca
// *****************************************************************************

// *****************************************************************************
// Example 1: Load the Buchnera.ent file and write to "out.fasta" all sequences
// with an effective number of codons (ENC) less than 45. Save the generated
// warnings to "warnings.txt". "Buchnera.ent" can be found at:
// ftp://ftp.genome.jp/pub/kegg/genomes/buc
// *****************************************************************************

program INCAblocks_example1;

{$APPTYPE CONSOLE}

uses
  SysUtils, Classes, Math, i2code, i2genes, i2files;

var
  Warnings: TStringList;
  n, GeneCnt: integer;
  tf: TextFile;

begin

  (*

  always call this procedure prior to loading gene files; this creates an
  array called "MetaLists" array with the following members:

  -> MetaLists[i2All] always has a single member MetaLists[i2All].Items[0]
     containing all genes; shorcut to this is the AllGenes global variable

  -> MetaLists[i2Ref] starts out with two members; Items[1] is the reference
     set and Items[0] is the non-reference set. Their shortcuts are:
     RefSet -> referring to MetaLists[i2Ref].Items[1]
     NonRef -> referring to MetaLists[i2Ref].Items[0]

  -> MetaLists[i2File].Items[0] in INCA is an always empty TGeneList; Items[1]
     is the first loaded genefile, Items[2] the second and so on; these are
     not created automatically by ParseXXX procedures, you have to do this by 
     myGeneFile:=TGeneList.Create(i2File); ParseXXX(myGeneFile, .....)
     You could skip this altogether and load everything straight into AllGenes.

  -> MetaLists[i2Set] contains custom genesets, created using
     mySet:=TGeneList.Create(i2Set)
     MetaLists[i2Set].Items[0] is always here and contains unassigned genes

  -> MetaLists[i2Cluster] and MetaLists[i2Bin] may be treated the same way
     as i2Set; INCA normally uses those to store results of clustering and
     binning

  -> MetaLists[i2CogCat] are divided by NCBI COG functional annotations

  *)

  INCAblocksInit;

  //the Warnings are by default saved to a TStringList object passed to the
  //parsing procedure; you may pass "nil" to the procedure instead if you're
  //not interested in the problems during loading of genefiles
  Warnings := TStringList.Create;

  //first parameter is a TGeneList (this will normally be AllGenes)
  //second is the filename, third a TStringList or nil,
  //fourth is the minimum required gene length in codons
  //fifth is the maximum number of warnings allowed for accepted genes
  //sixth is whether to keep sequences in memory
  ParseENT(AllGenes, '../genomes/Buchnera.ent', Warnings, 100, 1, True);

  //the basic statistics, such as codon frequencies and ENC, are computed
  //during parsing

  AssignFile(TF, 'out.txt'); Rewrite(TF);

  GeneCnt:=0;
  for n:=0 to AllGenes.Count-1 do
    //AllGenes[n].ENC may be NaN (not a number) if ENC couldn't be computed
    if (not IsNaN(AllGenes[n].ENC)) and (AllGenes[n].ENC<35) then begin

      WriteLn(TF, '>' + AllGenes[n].Name + ', ENC='
        + FloatToStr( AllGenes[n].ENC ) );
      WriteLn(TF, AllGenes[n].Sequence);
      Inc(GeneCnt);

    end;

  CloseFile(TF);

  WriteLn( IntToStr(GeneCnt) + ' genes out of ' + IntToStr(AllGenes.Count-1)
    + ' have ENC < 35' );

  Warnings.SaveToFile('warnings.txt'); Warnings.Free;

end.
