// *****************************************************************************
// INCAblocks 2.1, release date 13-Feb-2006
// Maintained by: Fran Supek <fran.supek[at]gmail.com>
// INCAblocks may be copied and modified freely, but give credit where it's due
// Full version of INCA software can be found at http://bioinfo.hr/inca
// *****************************************************************************

// *****************************************************************************
// Example 4: Load all .ffn and .ent files from the folder "genomes" (you
// should have the Buchnera, S. oneidensis and E. coli genomes), create a 
// distance matrix of their average codon usages using Karlin and Mrazek's B
// and save it in the specified (see code) format. The matrix needs to be
// symmetrical, so use arithmethic means of B(g1|g2) and B(g2|g1). It can be
// used to construct a tree using T-REX software. Finally, output the codon
// frequency tables for all files to the screen.
// *****************************************************************************

program INCAblocks_example4;

{$APPTYPE CONSOLE}

uses
  SysUtils, Classes, Math, i2code, i2genes, i2files;

var
  n, m: integer;
  SearchRec: TSearchRec;
  AGL: TGeneList;
  TF: TextFile;
  dist: real;
  pttFile: string;
    
begin

  INCAblocksInit;
 
  //the loading part is fairly standard procedure  
  if FindFirst('../genomes/*.ffn', faAnyFile, SearchRec)=0 then
    repeat

      AGL := TGeneList.Create(i2File);  
      WriteLn('Parsing ../genomes/'+SearchRec.Name);
      ParseFFN(AGL, '../genomes/'+SearchRec.Name, nil, 100, 1, False);
      
      //also load the accompanying ptt because it contains organism name
      pttFile := Copy( '../genomes/'+SearchRec.Name, 1, 
        Length('../genomes/'+SearchRec.Name)-4 ) + '.ptt';
      if FileExists( pttFile ) then begin
        WriteLn('Parsing '+pttFile);
        ParsePTT(AGL, pttFile, nil, 100);
      end; 
      
    until FindNext(SearchRec)<>0;  
  
  if FindFirst('../genomes/*.ent', faAnyFile, SearchRec)=0 then
    repeat
    
      AGL := TGeneList.Create(i2File);  
      WriteLn('Parsing ../genomes/'+SearchRec.Name);
      ParseENT(AGL, '../genomes/'+SearchRec.Name, nil, 100, 1, False);
      
    until FindNext(SearchRec)<>0;  
  
  (* 
  Distance matrix format for a (4x4) distance matrix is as follows:

  Object1			0	10	15	18
  Object2			10	0	15	12.6
  Object3			15	15	0	24
  Object4			18	12.6	24	0 
  *) 
 
  AssignFile(TF, 'distance_matrix.txt'); Rewrite(TF);
  
  for n:=1 to MetaLists[i2File].Count-1 do begin

    Write( TF, IntToStr(n) + '_'
      + Copy( MetaLists[i2File].Items[n].Organism, 1, 7 ) );

    for m:=1 to MetaLists[i2File].Count-1 do begin

      dist := ( MetaLists[i2File].Items[n].Stats.B (
                  MetaLists[i2File].Items[m].Stats.CodonFreq
                ) + 
                MetaLists[i2File].Items[m].Stats.B (
                  MetaLists[i2File].Items[n].Stats.CodonFreq
                )
              ) / 2;
              
      if m = n then dist := 0;
      
      Write( TF, #9 + FloatToStrF( dist, ffFixed, 7, 3)  );  
      
    end;    

    WriteLn(TF, '');
    
  end;
  
  CloseFile(TF);

  WriteLn('');
  
  
  //now let's write the codon frequencies out to the screen
  
  //first the header row with organism names
  Write('             ');
  for n:=1 to MetaLists[i2File].Count-1 do
    Write(IntToStr(n) + '_'
      + Copy( MetaLists[i2File].Items[n].Organism, 1, 7 ) + '  ' );
  WriteLn('');    
  
  //and then the rows with the codon frequencies
  //the "iCode" global variable has a list of codons sorted by amino acid
  //"CodonChr" transforms the numeric representation of the codon (0-63) into
  //a string
  for m:=0 to 63 do begin
  
    Write( CodonChr( iCode.SortedCodons[m] ) + ' (' 
      + AminoList[ iCode.Table[ iCode.SortedCodons[m] ] ] + ')    ' );
      
    for n:=1 to MetaLists[i2File].Count-1 do
      Write( FloatToStrF(      
        MetaLists[i2File].Items[n].Stats.CodonFreq[ iCode.SortedCodons[m] ],
        ffFixed, 7, 3) + '      ' );  
    WriteLn(''); 
    
  end;
  
end.    