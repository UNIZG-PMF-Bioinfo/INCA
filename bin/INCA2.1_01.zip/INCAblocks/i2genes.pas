//******************************************************************************
// INCAblocks 2.1, release date 09-Feb-2006
// Maintained by: Fran Supek <fran.supek[at]gmail.com>
// INCAblocks may be copied and modified freely, but give credit where it's due
// Full version of INCA software can be found at http://bioinfo.hr/inca
// *****************************************************************************

unit i2genes;

interface

uses
  SysUtils, Types, Classes, math, i2code
    {$IFDEF INCA_FULL}, QStdCtrls, QComCtrls{$ENDIF};

type
  //an exception type
  EfsGeneError = class(Exception);
  EfsOrgMismatch = class(EfsGeneError);
  EfsInvalidFile = class(EfsGeneError);

  //some array types
  TPttColumns = array [1..10] of String;
  TCOGCount = array ['-'..'Z'] of Integer;
  TCOGCorrel = array ['-'..'Z'] of Single;
  TSCOP = array[0..4] of Integer;

  //an enumerated type
  TGeneListType = (i2All, i2Ref, i2File, i2Set, i2Cluster, i2Bin, i2CogCat, i2UserFreq);

  //forward declarations
  TGeneMetaList = class;
  TGeneList = class;

  TGene = class(TObject)
  private
    FSequence: string;  //setting this fires the Calculate procedure
    FUID: integer;
    FEffectiveCodons: integer;

    {the codon and aminoacid counts and frequencies are calculated only at the
    time the sequence is set or changed}
    FAminoCount: TAminoCount; FAminoFreq: TAminoFreq;
    FCodonCount: TCodonCount; FCodonFreq: TCodonFreq;


    FGC3s: Single;
    FHydro: Single; FHydroStdev: Single;
    FENC: Single;
    FSCUO: Single;

    FOwner: array[TGeneListType] of TGeneList;

  protected
    function GetMember(AType: TGeneListType): SmallInt;
    function GetOwner(AType: TGeneListType): TGeneList;
    procedure SetMember(AType: TGeneListType; ASet: SmallInt);
    function FreqToW(ACodonFreq: TCodonFreq): TCodonW;

    procedure SetSequence(AString: string);

  public
    //some general properties of each gene
    Name, Description, Synonym, Organism, UniProt, Translation: string;
    Length, LocationStart, LocationEnd, NCBI_GI, NCBI_GeneID: Integer;
    SCOP: TSCOP;
    COG, SuperCat: Char; Strand: Char;
    WarnCount: Integer;

    TrueInfo: boolean; //has info been read from ptt?(t) or guessed from ffn?(f)

    //does the gene meet clustering criteria? ie. is it above/below the cutoff
    InCluster: Boolean;
    NetX, NetY: Integer; //coordinates of the best-matching neuron in the SOM
    Flag: Boolean;

    Visible: Boolean; //does the gene show in the browser or plot?
    Checked: Boolean; //is there a checkmark next to it in the table?
    Highlighted: Boolean; //should it be shown differently in plot?
    HasGoMapping: Boolean; //is it mapped to a GO term?

    UData: array of Real; HasData: array of Boolean; DataCnt: integer;
    MatchCnt: integer;

    PropCache: single; //used to cache properties before sorting
    PropCacheWasNaN: boolean;

    //used to pre-calculate memberships when saving project
    //the FillMemberCache procedure should be invoked before reading this
    MemberCache: array[TGeneListType] of SmallInt;

    MoveTo: integer;

    PCAFreq: TCodonFreq;

    //RQA stuff
    SmoothedCache: array of array of Single;
    SmoothedAAI: Integer;
    RQAParamSweep: TObject;
    RQALoaded: Boolean;

    constructor Create;
    constructor CreateDummy;
    destructor Destroy; override;

    {this procedure is invoked automatically when the sequence changes}
    procedure Calculate; overload;
    //use this variant to avoid allocating memory for the sequence
    procedure Calculate(const ASeq: String); overload;
    procedure Calculate(ACodonCount: TCodonCount); overload;
    procedure Calculate(ACodonFreq: TCodonFreq); overload;

    function GetProp(Prop: Integer): Single;

    function B(ACodonFreq: TCodonFreq): Single; overload; //main function
    function B(AGeneList: TGeneList): Single; overload; //calls function above

    function MCB(ACodonFreq: TCodonFreq): Single; overload; //main function
    function MCB(AGeneList: TGeneList): Single; overload; //calls function above

    function EncPrime(ACodonFreq: TCodonFreq): Single; overload; //main
    function EncPrime(AGeneList: TGeneList): Single; overload;

    function Cai(ACodonW: TCodonW): Single; overload; //original
    function Cai(ACodonFreq: TCodonFreq): Single; overload; //calls func. above
    function Cai(AGeneList: TGeneList): Single; overload; //calls func. above

    function Fop(ACodonW: TCodonW): Single; overload;
    function Fop(ACodonFreq: TCodonFreq): Single; overload; //calls func. above
    function Fop(AGeneList: TGeneList): Single; overload; //calls func. above

    function MILC(ACodonFreq: TCodonFreq): Single; overload;
    function MILC(AGeneList: TGeneList): Single; overload;

    function MELP(GroupFreq, RefFreq: TCodonFreq): Single;

    function GCB(GroupFreq, RefFreq: TCodonFreq): Single;

    function BelongsTo(Prop: Integer): Boolean;
    function GetAllText: string;
    function GetTabText: string;

    property AminoCount: TAminoCount read FAminoCount;
    property AminoFreq: TAminoFreq read FAminoFreq;
    property CodonCount: TCodonCount read FCodonCount;
    property CodonFreq: TCodonFreq read FCodonFreq;

    property GC3s: Single read FGC3s;  //this is G+C at silent sites only
    property ENC: Single read FENC;
    property SCUO: Single read FSCUO;
    property Hydro: Single read FHydro;
    property HydroStdev: Single read FHydroStdev;
    property Sequence: string read FSequence write SetSequence;
    property EffectiveCodons: integer read FEffectiveCodons;
    property AllText: string read GetAllText;

    property Member[AType: TGeneListType]: SmallInt
      read GetMember write SetMember;
    property Owner[AType: TGeneListType]: TGeneList
      read GetOwner;
    property UID: Integer read FUID;

  end;

  TGeneList = class(TList)
  private
    //set this to show progress information (optional), uses SimpleText property
    FGeneListType: TGeneListType;

    FENC: Single; FGC3: Single;
    FXTable: TCodonFreq;

    FNuclCount: TNuclCount;
    FNuclFreq: TNuclFreq;
    FBgCodonFreq: TCodonFreq; FBgNuclFreq: TNuclFreq;
    FAANormFactor: Single;      //frequency of the most common aminoacid
    FCodonW: TCodonW;  //relative codon abundances for CAI calculation

    FOwner: TGeneMetaList;

    FStats: TGene;

    FSequences: TStringList;

  protected
    //function CompareGenes(Item1, Item2: Pointer): Integer;
    function GetItem(Index: Integer): TGene;
    //procedure SetItem(Index: Integer; AGene: TGene);
    function GetCheckedCount: Integer;
    function GetVisibleCount: Integer;
    function GetDataCount: integer;

  public
    {$IFDEF INCA_FULL}StatusBar: TStatusBar;{$ENDIF}
    FirstFile: Boolean;
    Organism: String;
    Filename: String;
    IgnoredCnt: Integer;

    CalcDue: Boolean;

    {a list type *must* be specified at the time of creation}
    constructor Create(AGeneListType: TGeneListType);
    constructor CreateDummyFromVisible;
    constructor CreateDummy;
    destructor Destroy; override;
    destructor DestroyDummy;

    {similar to Calculate procedure of the TGene class, but computes
     the frequencies from the values of the member genes, not from the sequence
     because of speed. must be invoked manually after adding/removing genes to
     update values}
    procedure Calculate;

    function Add(AGene: TGene): Integer;
    function Remove(AGene: TGene): Integer;

    function IndexOf(AGene: TGene): Integer;
    function TextSearch(const s:string):Integer;
    function IdentifierSearch(const s:string):Integer;
    function DescriptionSearch(const s:string):Integer;

    function FindUID(aUID: Integer): TGene;

    procedure Clear; override;

    //SortBy = sort criteria (eg. B, CAI...) encoded into integer
    procedure Sort(SortBy: Integer);

    property Items[Index: Integer]: TGene read GetItem{ write SetItem}; default;
    property NuclFreq: TNuclFreq read FNuclFreq;
    property BgNuclFreq: TNuclFreq read FBgNuclFreq;
    property BgCodonFreq: TCodonFreq read FBgCodonFreq;

    property XTable: TCodonFreq read FXTable;
    property GeneListType: TGeneListType read FGeneListType;
    property CodonW: TCodonW read FCodonW;

    property Owner: TGeneMetaList read FOwner;

    property Stats: TGene read FStats;

    property Sequences: TStringList read FSequences;

    property CheckedCount: Integer read GetCheckedCount;
    property VisibleCount: Integer read GetVisibleCount;
    property DataCount: Integer read GetDataCount;
  end;



  TGeneMetaList = class(TList)
  //contains a list of genelists, frees them on deletion
  private
    FMemberType: TGeneListType; //type of members: genomes, clusters...
  protected
    function GetItem(Index: Integer): TGeneList;
    //procedure SetItem(Index: Integer; AGeneList: TGeneList);
    procedure Notify(Ptr: Pointer; Action: TListNotification); override;
  public
    constructor Create(AGeneListType: TGeneListType);
    //Add, Remove or Insert should never be invoked manually
    //they are used by the Create and Destroy methods of the TGeneList
    function Add(AGeneList: TGeneList): Integer;
    function Remove(AGeneList: TGeneList): Integer;
    procedure Insert(Index: Integer; AGeneList: TGeneList);
    procedure Delete(Index: Integer);
    procedure Clear;
    function PercentAssigned: single;
    function IndexOf(AGeneList: TGeneList): Integer;
    property MemberType: TGeneListType read FMemberType;
    property Items[Index: Integer]: TGeneList
      read GetItem{ write SetItem}; default;
  end;

procedure INCAblocksInit;

function CompareGenes(Item1, Item2: Pointer): Integer;
function CompareGenesRev(Item1, Item2: Pointer): Integer;

function Prop2String(Prop: Integer):String;
function Freq2String(Prop: Integer):String;
function Group2String(Prop: Integer): string;
function GLT2String(AGLT: TGeneListType):String;

function EncodeProp(const PropType, RelTo, GroupNo, FreqType: Byte):integer;
procedure DecodeProp(const Prop: Integer; var PropType, RelTo, GroupNo,
                       FreqType:Byte);
function PropToGeneList(const Prop: integer): TGeneList;
function PropIsPCA(const Prop: integer):boolean;
function PropGroupNo(const Prop: integer):byte;

function GetFreq(Prop: Integer):TCodonFreq;
function GetCount(Prop: Integer):TCodonCount;
function GetAminoFreq(Prop: Integer):TAminoFreq;

procedure FillMemberCache;

//this calls calculate for all GeneLists of all types
procedure RecalcAllGeneLists;

var
  MetaLists: array [TGeneListType] of TGeneMetaList;
  iCode: TCode;
  AllGenes: TGeneList;  // will point to MetaLists[i2All].Items[0]
  RefSet: TGeneList; // will point to MetaLists[i2Ref].Items[1]
  NonRef: TGeneList; // will point to MetaLists[i2Ref].Items[0]
  LengthThreshold: integer = 100;
  WarnTolerance: integer = 1;
  WarnIntolerant: boolean = False;
  KeepSeqsInMemory: boolean = True;
  UIDCounter: Integer = 0;
  UDataLabels: array of string;

const
  UserDataIndex = 20;
  PCADataIndex = 19;

implementation

procedure INCAblocksInit;
var
  AGLT: TGeneListType;
begin
  iCode:=TCode.Create; iCode.TableIndex:=1;
  for AGLT:=Low(TGeneListType) to High(TGeneListType) do begin
    MetaLists[AGLT]:=TGeneMetaList.Create(AGLT);
  end;
  AllGenes:=MetaLists[i2All].Items[0];
  RefSet:=MetaLists[i2Ref].Items[1];
  NonRef:=MetaLists[i2Ref].Items[0];
end;

function EncodeProp(const PropType, RelTo, GroupNo, FreqType: Byte):integer;
begin
  Result:=PropType + RelTo*32 + GroupNo*256 + FreqType*16384;
end;

procedure DecodeProp(const Prop: Integer; var PropType, RelTo, GroupNo,
                       FreqType:Byte);
begin
  PropType:=Prop and 31;  //first 5 bits (1-5)
  RelTo:=(Prop and 224) shr 5; //3 bits (6, 7, 8)
  GroupNo:=(Prop and 16128) shr 8; //6 bits (9, 10, 11, 12, 13, 14)
  FreqType:=(Prop and 49152) shr 14; //2 bits (15, 16)
end;

function PropToGeneList(const Prop: integer): TGeneList;
var
  PropType, RelTo, GroupNo, FreqType: Byte;
begin
  DecodeProp(Prop, PropType, RelTo, GroupNo, FreqType);
  if GroupNo<MetaLists[TGeneListType(RelTo)].Count then begin //everything is ok
    Result:=MetaLists[TGeneListType(RelTo)].Items[GroupNo];
  end else
    Result:=AllGenes;
end;

function PropIsPCA(const Prop: integer):boolean;
var
  PropType, RelTo, GroupNo, FreqType: Byte;
begin
  DecodeProp(Prop, PropType, RelTo, GroupNo, FreqType);
  Result:=(PropType=PCADataIndex);
end;

function PropGroupNo(const Prop: integer):byte;
var
  PropType, RelTo, GroupNo, FreqType: Byte;
begin
  DecodeProp(Prop, PropType, RelTo, GroupNo, FreqType);
  Result:=GroupNo;
end;

//******************************************************************************
// the GetFreq & GetCounts function
//******************************************************************************
function GetFreq(Prop: Integer):TCodonFreq;
var
  PropType, RelTo, GroupNo, FreqType, q: Byte;
  AList: TGeneList;
begin
  DecodeProp(Prop, PropType, RelTo, GroupNo, FreqType);
  if GroupNo<MetaLists[TGeneListType(RelTo)].Count then begin //everything is ok
    AList:=MetaLists[TGeneListType(RelTo)].Items[GroupNo];
    AList.Calculate; // !!!
    Result:=AList.Stats.CodonFreq;
  end else
    for q:=0 to 63 do Result[q]:=0;  //currently non-existant group
end;

function GetCount(Prop: Integer):TCodonCount;
var
  PropType, RelTo, GroupNo, FreqType, q: Byte;
  AList: TGeneList;
begin
  DecodeProp(Prop, PropType, RelTo, GroupNo, FreqType);
  if GroupNo<MetaLists[TGeneListType(RelTo)].Count then begin //everything is ok
    AList:=MetaLists[TGeneListType(RelTo)].Items[GroupNo];
    AList.Calculate; // !!!
    Result:=AList.Stats.CodonCount;
  end else
    for q:=0 to 63 do Result[q]:=0;  //currently non-existant group
end;

function GetAminoFreq(Prop: Integer):TAminoFreq;
var
  PropType, RelTo, GroupNo, FreqType: Byte;
  c: Char;
  AList: TGeneList;
begin
  DecodeProp(Prop, PropType, RelTo, GroupNo, FreqType);
  if GroupNo<MetaLists[TGeneListType(RelTo)].Count then begin //everything is ok
    AList:=MetaLists[TGeneListType(RelTo)].Items[GroupNo];
    AList.Calculate; // !!!
    Result:=AList.Stats.AminoFreq;
  end else
    for c:='A' to 'Z' do Result[c]:=0;  //currently non-existant group
end;

//******************************************************************************
// implementation of TGene class
//******************************************************************************

constructor TGene.Create;
var
  AGLT: TGeneListType;
begin
  inherited Create;
  for AGLT:=Low(MetaLists) to High(MetaLists) do begin
    if AGLT=i2UserFreq then Continue;
    MetaLists[AGLT].Items[0].Add(self);
    //'Add' the gene to list zero (unassigned genes) in the current MetaList
    //this also sets the Owner property
  end;
  NetX:=-1; NetY:=-1; WarnCount:=0;
  SetLength(UData, 0); SetLength(HasData, 0); DataCnt:=0; MatchCnt:=0;
  HasGoMapping:=False;
  FUID:=UIDCounter; inc(UIDCounter);
  self.TrueInfo:=False;
  RQAParamSweep:=nil;
end;

constructor TGene.CreateDummy;
begin
  inherited Create;
end;

destructor TGene.Destroy;
var AGLT:TGeneListType;
begin
  for AGLT:=Low(TGeneListType) to High(TGeneListType) do
    if FOwner[AGLT]<>nil then FOwner[AGLT].Remove(self);
    //remove gene from all genelists
  inherited Destroy;
end;

function TGene.GetOwner(AType: TGeneListType): TGeneList;
begin
  Result:=FOwner[AType];
end;

function TGene.GetMember(AType: TGeneListType): SmallInt;
begin
  if FOwner[AType]<>nil then
    Result:=FOwner[AType].Owner.IndexOf(FOwner[AType])
  else
    Result:=-1;
end;

procedure TGene.SetMember(AType: TGeneListType; ASet: SmallInt);
begin
  if FOwner[AType]<>nil then FOwner[AType].Remove(self);
  Assert(ASet<MetaLists[AType].Count, 'Assertion failure: TGene.SetMember');
  if ASet>-1 then MetaLists[AType].Items[ASet].Add(self);
end;

function TGene.B(ACodonFreq: TCodonFreq): Single;
var q: Byte;
begin
  Result:=0;
  for q:=0 to 63 do
    Result:=Result +
      Abs(self.CodonFreq[q]-ACodonFreq[q])*self.AminoFreq[iCode.Table[q]];
end;

function TGene.B(AGeneList: TGeneList): Single;
begin Result:=B(AGeneList.Stats.CodonFreq); end;

function TGene.MCB(ACodonFreq: TCodonFreq): Single;
var
  q, ap: Byte; //"ap" is the number of aminos contributing to the index
  c: Char;
begin
  Result:=0; ap:=0;
  for q:=0 to 63 do if (ACodonFreq[q]>0) and (CodonCount[q]>0) then
    Result:=Result + Sqr( self.CodonFreq[q] - ACodonFreq[q] ) / ACodonFreq[q]
      * Log10( self.AminoCount[ iCode.Table[q] ] );
  for c:='A' to 'Z' do
    if (iCode.AminoFold[c]>1) //and (c<>'X')
      and (self.AminoCount[c]>0) then inc(ap);
  if ap>0 then Result:=Result/ap else Result:=0;
end;

function TGene.MCB(AGeneList: TGeneList): Single;
begin Result:=MCB(AGeneList.Stats.CodonFreq); end;

function TGene.MILC(AGeneList: TGeneList): Single;
begin
  Result:=MILC(AGeneList.Stats.CodonFreq);
end;

function TGene.MILC(ACodonFreq: TCodonFreq): Single;
var
  x2, O, E: Single; q, cf: Byte; c: char;
begin
  x2:=0; cf:=0;

  for q:=0 to 63 do begin
    if iCode.Table[q]='X' then Continue;
    O:=self.CodonFreq[q];
    E:=ACodonFreq[q];
    if (E>0) and (O>0) then
      x2:=x2+self.CodonCount[q]*ln(O/E);
  end;

  for c:='A' to 'Z' do
    if c='X' then Continue else
      if AminoCount[c]>0 then cf:=cf+iCode.Aminofold[c]-1;

  Result := ( (2*x2-cf) / (self.EffectiveCodons-self.AminoCount['X']) ) + 0.5;
end;

function TGene.MELP(GroupFreq, RefFreq: TCodonFreq): Single;
var tm: single;
begin
  tm:=MILC(RefFreq);
  if IsNan(tm) or (tm=0) then Result:=NaN else Result:=MILC(GroupFreq)/tm;
end;

function TGene.Cai(ACodonW: TCodonW): Single;
var q:Byte; r:Real; n:Integer;
begin
  r:=0; n:=0;
  for q:=0 to 63 do
    if (iCode.Table[q]<>'X') and (iCode.AminoFold[iCode.Table[q]]>1) then begin
      r:=r+CodonCount[q]*Ln(ACodonW[q]);
      n:=n+CodonCount[q];
    end;
  Result:=Exp(r/n);
end;

function TGene.Fop(ACodonW: TCodonW): Single;
var
  CntOp: integer; q: byte;
begin
  CntOp:=0;
  for q:=0 to 63 do
    if (iCode.Table[q]<>'X') and (iCode.AminoFold[iCode.Table[q]]>1)
      and (ACodonW[q]>0.9) then CntOp:=CntOp+self.CodonCount[q];
  Result:=CntOp/self.EffectiveCodons;
end;

function TGene.GCB(GroupFreq, RefFreq: TCodonFreq): Single;
var q:byte;
begin
  Result:=0;
  for q:=0 to 63 do
    if (iCode.AminoFold[iCode.Table[q]]>1) then begin
      if GroupFreq[q]=0 then Continue;  //frequency in the "genome"
      if RefFreq[q]=0 then begin  //freq in the "targets"; if low, use -5 cutoff
        Result := Result - 5.0*CodonCount[q]; Continue;
      end;
      Result := Result + Max( Ln(RefFreq[q]/GroupFreq[q]), -5.0 )
        * self.CodonCount[q];
    end;
  Result := Result / self.EffectiveCodons; //!!! does it include the stop codon?
end;

function TGene.EncPrime(ACodonFreq: TCodonFreq): Single;
//John A. Novembre, Mol Biol Evol 2002
var
  X2Value: TAminoFreq;   //chi square statistic for each amino acid
  nFoldPresent: TFoldCount; //how many n-fold aminos present more than 1 times
  FkSum, FkAvg: TFoldFreq; //sum & avg of homozygosity for each fold
  c: char; q: byte; HomoZyg: Real;
  n: integer;
begin
  //initialize variables
  for c:='A' to 'Z' do X2Value[c]:=0;
  for q:=1 to 64 do begin
    FkSum[q]:=0; nFoldPresent[q]:=0;
  end;
  Result:=0;

  //now calculate the X2
  for q:=0 to 63 do
    if ACodonFreq[q]>0 then
      X2Value[iCode.Table[q]]:=X2Value[iCode.Table[q]]
        + ( Sqr(FCodonFreq[q]-ACodonFreq[q]) / ACodonFreq[q] );

  for c:='A' to 'Z' do begin
    if c='X' then Continue;  //skip stop codons when computing ENCprime
    //also skip rarely used (less then 5 times) or absent aminos
    if (FAminoCount[c]<5) then Continue;
    HomoZyg:=( FAminoCount[c]*X2Value[c] + FAminoCount[c] - iCode.AminoFold[c] )
      / ( iCode.AminoFold[c] * ( FAminoCount[c] - 1 ) );
    //if HomoZyg>0.0000001 then begin
    FkSum[iCode.AminoFold[c]]:=FkSum[iCode.AminoFold[c]]+HomoZyg;
    inc(nFoldPresent[iCode.AminoFold[c]]);
    //end;
  end;

  for n:=Low(iCode.nFoldAminos) to High(iCode.nFoldAminos) do
    if iCode.nFoldAminos[n]>0 then begin  //if n-fold aminos exist, ie skip 5,7..
      if nFoldPresent[n]>0 then //there is at least one good amino in red. class
        FkAvg[n]:=FkSum[n]/nFoldPresent[n]
      else if (n=3) and (nFoldPresent[2]>0)  //special case, approx missing Ile
        and (nFoldPresent[4]>0) and (iCode.nFoldAminos[3]>0) then
        FkAvg[3]:=(FkSum[2]/nFoldPresent[2]+FkSum[4]/nFoldPresent[4])*0.5
      else begin  //Novembre's assumption; every gene will have EncPrime calc'ed
        FkAvg[n]:=1/n;
      end;
      Result:=Result+iCode.nFoldAminos[n]/FkAvg[n];
    end;

  //proteins that are very short and with extreme aminoacid composition
  if Result>61 then Result:=61;
end;

function TGene.EncPrime(AGeneList: TGeneList): Single;
begin Result:=EncPrime(AGeneList.Stats.CodonFreq); end;

function TGene.Cai(ACodonFreq: TCodonFreq): Single;
begin Result:=Cai(FreqToW(ACodonFreq)); end;

function TGene.Cai(AGeneList: TGeneList): Single;
begin Result:=Cai(FreqToW(AGeneList.Stats.CodonFreq)); end;

function TGene.Fop(ACodonFreq: TCodonFreq): Single;
begin Result:=Fop(FreqToW(ACodonFreq)); end;

function TGene.Fop(AGeneList: TGeneList): Single;
begin Result:=Fop(FreqToW(AGeneList.Stats.CodonFreq)); end;

function TGene.FreqToW(ACodonFreq: TCodonFreq): TCodonW;
var
  MaxFreq:TAminoFreq; c:Char; q:integer;
begin
  for c:='A' to 'Z' do MaxFreq[c]:=0;
  for q:=0 to 63 do
    if ACodonFreq[q]>MaxFreq[iCode.Table[q]] then MaxFreq[iCode.Table[q]]:=ACodonFreq[q];
  for q:=0 to 63 do begin
    if MaxFreq[iCode.Table[q]]>0 then
      Result[q]:=ACodonFreq[q]/MaxFreq[iCode.Table[q]]
    else
      Result[q]:=1;
    if Result[q]<0.01 then Result[q]:=0.01;  //Bulmer (1998) adjustment
  end;
end;

procedure TGene.Calculate;
begin Calculate(CountCodons(self.Sequence)); end;

procedure TGene.Calculate(const ASeq: String);
begin Calculate(CountCodons(ASeq)); end;

procedure TGene.Calculate(ACodonFreq: TCodonFreq);
var ACodonCount:TCodonCount; p:Byte;
begin
  for p:=0 to 63 do ACodonCount[p]:=
    Round( ACodonFreq[p] * 100000 ); //!!!
  Calculate(ACodonCount);
end;

procedure TGene.Calculate(ACodonCount: TCodonCount);
var
  n,q:Integer; c:Char; ts:String;
  SValue: TAminoFreq;   //sum of squares of codon freqs for each aminoacid
  nFoldPresent: TFoldCount; //how many n-fold aminos present more than 1 times
  FkSum, FkAvg: TFoldFreq; //sum & avg of homozygosity for each fold
  StrangeGene: Boolean; //if Enc can't be calculated
  HomoZyg, HydroSumSq: Real;
  SilentCodons, SilentGc3: Integer;
begin
  //set all counts to zero
  for c:='A' to 'Z' do
    begin FAminoCount[c]:=0; SValue[c]:=0; end;
  for q:=1 to 64 do begin
    FkSum[q]:=0; nFoldPresent[q]:=0;
  end;

  FEffectiveCodons:=0; SilentCodons:=0; SilentGc3:=0; StrangeGene:=False;

  FCodonCount:=ACodonCount;
  for q:=0 to 63 do begin
    inc(FEffectiveCodons, FCodonCount[q]);
    inc(FAminoCount[iCode.Table[q]], FCodonCount[q]);
  end;

  //now calculate the frequencies, ENC, GC3s and hydropathy
  for q:=0 to 63 do begin
    if FAminoCount[iCode.Table[q]]>0 then
      FCodonFreq[q]:=FCodonCount[q]/FAminoCount[iCode.Table[q]]
    else
      FCodonFreq[q]:=0;
    SValue[iCode.Table[q]]:=SValue[iCode.Table[q]]+Sqr(FCodonFreq[q]);
    //the SValue is used later to compute ENC
    if q in iCode.SilentCodons //a codon where 3rd base mutations are silent
      then begin
        ts:=CodonChr(q);
        Inc(SilentCodons, FCodonCount[q]);
        if (ts[3]='G') or (ts[3]='C') then Inc(SilentGC3, FCodonCount[q]);
      end;
  end;
  FGC3s:=SilentGC3/SilentCodons;

  FENC:=0;
  FHydro:=0; HydroSumSq:=0;

  for c:='A' to 'Z' do begin
    if FEffectiveCodons>0 then
      FAminoFreq[c]:=FAminoCount[c]/FEffectiveCodons
    else
      FAminoFreq[c]:=0;

    FHydro:=FHydro+FAminoCount[c]*HydroScore[c];
    HydroSumSq:=HydroSumSq+FAminoCount[c]*Sqr(HydroScore[c]);

    if (c='X') then Continue;  //skip stop codons when computing ENC
    //also skip rarely used or absent aminos
    if (FAminoCount[c]<=1) or (FAminoCount[c]*SValue[c]<=1) then Continue;
    HomoZyg:=(FAminoCount[c]*SValue[c]-1)/(FAminoCount[c]-1);
    //if HomoZyg>0.0000001 then begin
      FkSum[iCode.AminoFold[c]]:=FkSum[iCode.AminoFold[c]]+HomoZyg;
      //FENC:=FENC+1/HomoZyg;
      inc(nFoldPresent[iCode.AminoFold[c]]);
    //end;
  end;

  FHydroStdev:=Sqrt(FEffectiveCodons*HydroSumSq-Sqr(FHydro))/FEffectiveCodons;
  FHydro:=FHydro/FEffectiveCodons;

  for n:=2 to 8 do //in some transl. tables Ser and Thr are 8-fold aminos!
    if iCode.nFoldAminos[n]>0 then begin
      if (FkSum[n]>0) and (nFoldPresent[n]>0) then
        FkAvg[n]:=FkSum[n]/nFoldPresent[n]
      else if (n=3) and (nFoldPresent[2]>0)  //special case, approx missing Ile
        and (nFoldPresent[4]>0) and (iCode.nFoldAminos[3]>0) then
        FkAvg[3]:=(FkSum[2]/nFoldPresent[2]+FkSum[4]/nFoldPresent[4])*0.5
      else begin
        StrangeGene:=True; Break;
      end;
      FENC:=FENC+iCode.nFoldAminos[n]/FkAvg[n];
    end;

  FENC:=FENC+iCode.nFoldAminos[1]; //normally add 2 to compensate for Met and Trp

  //proteins that are very short and with extreme aminoacid composition
  if FENC>61 then FENC:=61;
  //set to 0 if couldn't be calculated
  if StrangeGene then FENC:=NaN;

  //now calculate SCUO
  for c:='A' to 'Z' do SValue[c]:=0; //clear this for re-use

  for q:=0 to 63 do
    if FCodonFreq[q]>0 then
      SValue[iCode.Table[q]]:=SValue[iCode.Table[q]]
        - FCodonFreq[q]*Log10(FCodonFreq[q]);

  FSCUO:=0;
  for c:='A' to 'Z' do
    if (c<>'X') and (iCode.AminoFold[c]>1) then begin  //skip stops and Met (Trp)
      FSCUO:=FSCUO+FAminoFreq[c]*(1+SValue[c]/Log10(1/iCode.AminoFold[c]));
    end;
end;

procedure TGene.SetSequence(AString: string);
begin
  if AString<>FSequence then begin  //if there are changes
    FSequence:=Astring;             //set the field to new value
    //Calculate;                    //and calculate everything!
    //-> INCA 2.1 doesn't calculate automatically
  end;
end;

function TGene.GetProp(Prop: Integer):Single;
const
  DefaultData: Single = 0;
var
  PropType, RelTo, GroupNo, FreqType: Byte;
  AFreq: TCodonFreq; AList: TGeneList;  AGLT:TGeneListType;
  RB: Single;
begin
  DecodeProp(Prop, PropType, RelTo, GroupNo, FreqType);

  //Assert(GroupNo<MetaLists[AGLT].Count);
  if PropType<=18 then begin
    AGLT:=TGeneListType(RelTo);
    AList:=MetaLists[AGLT].Items[GroupNo];
    AFreq:=AList.Stats.CodonFreq;
  end;

  if PropType in [3,10,11,12] then MetaLists[i2Ref].Items[1].Calculate;

  case PropType of
    0: Result:=CAI(MetaLists[i2Ref].Items[1].CodonW);
    1: Result:=ENC; //not affected by the choice of 'relative to'
    2: Result:=B(AFreq);
    3: begin RB:=B(MetaLists[i2Ref].Items[1].Stats.CodonFreq);
       if RB>0 then Result:=B(AFreq)/RB; end;
    4: Result:=MCB(AFreq);
    5: Result:=EncPrime(AFreq);
    6: Result:=MILC(AFreq);
    7: Result:=SCUO;
    8: Result:=self.Member[TGeneListType(RelTo)];
    9: Result:=DefaultData; //separator
   10: Result:=Fop(MetaLists[i2Ref].Items[1].CodonW);
   11: Result:=MELP(AFreq, MetaLists[i2Ref].Items[1].Stats.CodonFreq);
   12: Result:=GCB(AFreq, MetaLists[i2Ref].Items[1].Stats.CodonFreq);
   13: Result:=EffectiveCodons;
   14: Result:=LocationStart;
   15: Result:=GC3s;
   16: Result:=Hydro;
   UserDataIndex: //user data, GroupNo stores which data
     if (GroupNo<DataCnt) and (HasData[GroupNo]) then
       Result:=UData[GroupNo]
     else
       Result:=DefaultData;
   PCADataIndex: //a PCA frequency, GroupNo stores which axis
     if (GroupNo<63) then Result:=PCAFreq[GroupNo] else Result:=DefaultData;
  end; //case
end;

function TGene.BelongsTo(Prop: Integer): Boolean;
var
  PropType, RelTo, GroupNo, FreqType: Byte;
begin
  DecodeProp(Prop, PropType, RelTo, GroupNo, FreqType);
  Result:=(self.Member[TGeneListType(RelTo)]=GroupNo);
end;

function TGene.GetAllText:string;
begin
  Result:=self.Name+#13#10+self.Description+#13#10+self.Synonym;
end;

function TGene.GetTabText:string;
begin
  Result:=self.Name+#9+self.Description+#9+self.Synonym;
end;

//******************************************************************************
// the FillMemberCache procedure
//******************************************************************************
procedure FillMemberCache;
var
  AGLT: TGeneListType;
  n, m: integer;
begin
  for AGLT:=Low(TGeneListType) to High(TGeneListType) do
    for n:=0 to MetaLists[AGLT].Count-1 do
      with MetaLists[AGLT].Items[n] do
        for m:=0 to Count-1 do begin
          Items[m].MemberCache[AGLT]:=n;
        end;
end;

//******************************************************************************
// implementation of TGeneList class
//******************************************************************************

constructor TGeneList.Create(AGeneListType: TGeneListType);
begin
  inherited Create;
  FGeneListType:=AGeneListType;
  FOwner:=MetaLists[AGeneListType];
  if (FOwner<>nil) and (FOwner.IndexOf(self)<0) then
    FOwner.Add(self);
  FStats:=TGene.CreateDummy;
  IgnoredCnt:=0;
end;

constructor TGeneList.CreateDummyFromVisible;
var
  n:integer;
begin
  inherited Create;
  for n:=0 to AllGenes.Count-1 do begin
    if AllGenes[n].Visible then inherited Add(AllGenes[n]);
  end;
  FStats:=TGene.CreateDummy;
end;

constructor TGeneList.CreateDummy;
var
  n:integer;
begin
  inherited Create;
  FStats:=TGene.CreateDummy;
end;

destructor TGeneList.Destroy;
begin
  self.Clear;
  FStats.Free;
  FOwner.Remove(self);
  //inherited Destroy; <- don't call Destroy as it calls Clear again
end;

destructor TGeneList.DestroyDummy;
begin
  FStats.Free;
end;

procedure TGeneList.Sort(SortBy: Integer);
var
  n: integer;
begin
  for n:=0 to self.Count-1 do begin
    Items[n].PropCache:=Items[n].GetProp(Abs(SortBy));
    if isNan(Items[n].PropCache) then begin
      Items[n].PropCache:=-MaxSingle;
      Items[n].PropCacheWasNaN:=True;
    end else
      Items[n].PropCacheWasNaN:=False;
  end;
  if SortBy>0 then inherited Sort(CompareGenes)
    else inherited Sort(CompareGenesRev);
end;

function CompareGenes(Item1, Item2: Pointer): Integer;
var p1,p2:Single;
begin
  p1:=TGene(Item1).PropCache;
  p2:=TGene(Item2).PropCache;
  if p1>p2 then Result:=1 else
    if p1<p2 then Result:=-1 else Result:=0;
end;

function CompareGenesRev(Item1, Item2: Pointer): Integer;
var p1,p2:Single;
begin
  p1:=TGene(Item1).PropCache;
  p2:=TGene(Item2).PropCache;
  if p1>p2 then Result:=-1 else
    if p1<p2 then Result:=1 else Result:=0;
end;

procedure TGeneList.Calculate;
var
  n,q: integer; AGene:TGene; c:char; ts:string; tr:Single;
  ACodonCount: TCodonCount;
begin
  if not CalcDue then Exit else CalcDue:=False;

  //if this is a UserFreq-type list, skip most parts as there are no CodonCounts
  if Self.FGeneListType<>i2UserFreq then begin

    //set codon counts to zero
    for q:=0 to 63 do ACodonCount[q]:=0;

    //genelist codon counts are the sums of counts of its genes
    for n:=0 to Count-1 do begin
      AGene:=Items[n];
      for q:=0 to 63 do
        inc(ACodonCount[q], AGene.CodonCount[q]);
    end;

    (* FStats is actually a TGene object
       TGeneList has only some stats of its own, some are calc'ed by FStats
       -> in FStats: codon and aa counts and frequencies, ENC, hydropathy, GC3s
       -> in TGeneList: nucleotide freq, silent nucl freq & derived "silent codn
          freq", W for CAI calculation, AANormFactor, xTable *)
    FStats.Calculate(ACodonCount);

    //now calculate the single nucleotide frequencies
    FNuclCount:=Codon2NuclCount(Stats.FCodonCount);
    if Stats.FEffectiveCodons>0 then
      for q:=0 to 3 do
        FNuclFreq[q]:=FNuclCount[q]/(Stats.FEffectiveCodons*3);

    //...and codon frequencies predicted from background nucleotide composition
    FBgNuclFreq:=iCode.Codon2SilentNuclFreq(Stats.FCodonCount);
    FBgCodonFreq:=iCode.NuclToCodonFreq( FBgNuclFreq );

    //store the most frequently occuring amino into FAANormFactor
    FAANormFactor:=0;
    for c:='A' to 'Z' do
      if Stats.FAminoFreq[c]>FAANormFactor then
        FAANormFactor:=Stats.FAminoFreq[c];

  end;

  //relative codon abundances (to speed up CAI calculation later)
  if Count>0 then
    FCodonW:=Stats.FreqToW(Stats.CodonFreq);

  //XTable to measure deviation from normal frequencies
  for q:=0 to 63 do begin
    FxTable[q]:=Sqr(Stats.FCodonFreq[q]-iCode.NormalCodonFreq[q])/
      iCode.NormalCodonFreq[q];
    if Stats.FCodonFreq[q]<iCode.NormalCodonFreq[q] then FXTable[q]:=-FXTable[q];
  end;


end;

function TGeneList.Add(AGene: TGene): Integer;
begin
  self.CalcDue:=True;
  if AGene.FOwner[GeneListType]<>nil then
    AGene.FOwner[GeneListType].Remove(AGene);
  AGene.FOwner[GeneListType]:=self;
  Result:=inherited Add(AGene);
end;

function TGeneList.GetItem(Index: Integer): TGene;
begin
  Result:=inherited Items[Index];
end;

function TGeneList.IndexOf(AGene: TGene): Integer;
begin
  Result:=inherited IndexOf(AGene);
end;

function TGeneList.Remove(AGene: TGene): Integer;
begin
  self.CalcDue:=True;
  AGene.FOwner[GeneListType]:=nil;
  Result:=inherited Remove(AGene);
end;

procedure TGeneList.Clear;
var
  n:integer; AGLT: TGeneListType; AGene: TGene;
begin
  if GeneListType=i2File then begin  //if clearing genome, free genes
    for n:=Count-1 downto 0 do
      Items[n].Free;

  end else begin
    if Owner.IndexOf(Self)>0 then  //can't clear list 0!
      for n:=Count-1 downto 0 do
        Items[n].Member[GeneListType]:=0;
  end;

  if Owner.IndexOf(Self)>0 then Assert(Count=0, 'Assert failed: TGeneList.Clear');
  if Count>0 then inherited Clear;
end;

function TGeneList.GetCheckedCount:integer;
var n:Integer;
begin
  Result:=0;
  for n:=0 to Count-1 do if Items[n].Checked then Inc(Result);
end;

function TGeneList.GetVisibleCount:integer;
var n:Integer;
begin
  Result:=0;
  for n:=0 to Count-1 do if Items[n].Visible then Inc(Result);
end;

function TGeneList.GetDataCount:integer;
begin
  if (Count>0) then Result:=Items[0].DataCnt else Result:=0;
end;

function TGeneList.TextSearch(const s:string):Integer;
var n:integer;
begin
  Result:=-1;
  for n:=0 to Count-1 do
    if Pos(UpperCase(s),UpperCase(Items[n].GetAllText))>0 then
      begin Result:=n; Exit; end;
end;

function TGeneList.IdentifierSearch(const s:string):Integer;
var n:integer;
begin
  Result:=-1;
  for n:=0 to Count-1 do
    if (UpperCase(s)=UpperCase(Items[n].Name)) or
      (UpperCase(s)=UpperCase(Items[n].Synonym)) then
      begin Result:=n; Exit; end;
end;

function TGeneList.DescriptionSearch(const s:string):Integer;
var n:integer;
begin
  Result:=-1;
  for n:=0 to Count-1 do
    if UpperCase(s)=UpperCase(Items[n].Description) then
      begin Result:=n; Exit; end;
end;


function TGeneList.FindUID(aUID: Integer):TGene;
var n:integer;
begin
  Result:=nil;
  for n:=0 to self.Count-1 do
    if Items[n].FUID=aUID then begin
      Result:=Items[n]; Break;
    end;
end;

procedure RecalcAllGeneLists;
var
  AGLT: TGeneListType;
  n: integer;
begin
  for AGLT:=Low(TGeneListType) to High(TGeneListType) do
    for n:=0 to MetaLists[AGLT].Count-1 do
      MetaLists[AGLT].Items[n].Calculate;

end;

//******************************************************************************
// implementation of the TGeneMetaList class
//******************************************************************************

constructor TGeneMetaList.Create(AGeneListType: TGeneListType);
var
  AGeneList: TGeneList;
  n: integer;
begin
  inherited Create;
  FMemberType:=AGeneListType;
  MetaLists[AGeneListType]:=self;
  AGeneList:=TGeneList.Create(FMemberType);
  Assert(IndexOf(AGeneList)=0, 'Assert failed: TGeneMetaList.Create');
  if FMemberType=i2Ref then TGeneList.Create(FMemberType); //ref. set 1
  if FMemberType=i2CogCat then begin
    AGeneList.Organism:='[-] '+COGList['-'];
    for n:=2 to system.Length(COGs) do begin
      AGeneList:=TGeneList.Create(FMemberType);
      AGeneList.Organism:='['+COGs[n]+'] '+COGList[COGs[n]];
    end;
  end;
end;

function TGeneMetaList.Add(AGeneList: TGeneList): Integer;
begin
  Result := inherited Add(AGeneList);
end;

function TGeneMetaList.GetItem(Index: Integer): TGeneList;
begin
  Result := inherited Items[Index];
end;

function TGeneMetaList.IndexOf(AGeneList: TGeneList): Integer;
begin
  Result := inherited IndexOf(AGeneList);
end;

procedure TGeneMetaList.Insert(Index: Integer; AGeneList: TGeneList);
begin
  inherited Insert(Index, AGeneList);
end;

procedure TGeneMetaList.Notify(Ptr: Pointer; Action: TListNotification);
begin
  //if Action = lnDeleted then TGeneList(Ptr).Free;
  inherited Notify(Ptr, Action);
end;

function TGeneMetaList.Remove(AGeneList: TGeneList): Integer;
begin
  Result:=IndexOf(AGeneList);
  Delete(Result);
end;

procedure TGeneMetaList.Delete(Index: Integer);
begin
  if Index=0 then Exit;
  self.Items[Index].Clear;
  inherited Delete(Index);
end;

procedure TGeneMetaList.Clear;
var
  n:integer;
begin
  if (FMemberType=i2Ref) or (FMemberType=i2CogCat) or (FMemberType=i2All) then Exit;
  for n:=Count-1 downto 1 do begin
    Items[n].Clear;
    self.Delete(n);
  end;
end;

function TGeneMetaList.PercentAssigned: single;
begin
  if AllGenes.Count>0 then
    Result:=(AllGenes.Count-Items[0].Count)/AllGenes.Count*100
  else
    Result:=0;
end;





{procedure TGeneMetaList.SetItem(Index: Integer; AGeneList: TGeneList);
begin
  inherited Items[Index] := AGeneList;
end;}

//************************************************

function GLT2String(AGLT: TGeneListType):String;
begin
  case AGLT of
    i2All: Result:='All genes';
    i2Ref: Result:='Reference';
    i2File: Result:='Genefile';
    i2Set: Result:='Custom set';
    i2Cluster: Result:='Cluster';
    i2Bin: Result:='Bin';
    i2CogCat: Result:='Category';
    i2UserFreq: Result:='User freq';
  else
    Result:='GLT2String Error!';
  end;
end;

function Prop2String(Prop: Integer):String;
var
  PropType, RelTo, GroupNo, FreqType: Byte;
  AFreq: TCodonFreq; AList: TGeneList;
  RB: Single;
  Flag: boolean;
begin
  Result:=''; //initialize
  Flag:=True;
  DecodeProp(Prop, PropType, RelTo, GroupNo, FreqType);

  case PropType of
    0: Result:='CAI | ';
    1: begin Flag:=False; Result:='ENC'; end;
    2: Result:='B | ';
    3: Result:='E | ';
    4: Result:='MCB | ';
    5: Result:='ENC'' | ';
    6: Result:='MILC | ';
    7: begin Flag:=False; Result:='SCUO'; end;
    9: begin Flag:=False; Result:='(none)'; end; //separator
    8: Result:='memb | ';
    10: Result:='Fop | ';
    11: Result:='MELP | ';
    17: Result:='MELP2 | ';
    18: Result:='MELP3 | ';

    12: Result:='GCB | ';
    13: begin Flag:=False; Result:='length'; end;
    14: begin Flag:=False; Result:='position'; end;
    15: begin Flag:=False; Result:='GC3s'; end;
    16: begin Flag:=False; Result:='hydro'; end;
    UserDataIndex: begin
      Flag:=False; Result:='data '+IntToStr(GroupNo);
    end;
    PCADataIndex: begin
      Flag:=False; Result:='PCA axis '+IntToStr(GroupNo+1);
    end;
  end;

  if not Flag then Exit;
  case TGeneListType(RelTo) of
    i2All:      begin Flag:=False; Result:=Result+'all'; end;
    i2File:   Result:=Result+'genfile ';
    i2Set:      Result:=Result+'custom ';
    i2Cluster:  Result:=Result+'cluster ';
    i2Bin:      Result:=Result+'bin ';
    i2UserFreq: Result:=Result+'f.table ';
    i2Ref:      begin Flag:=False;
                  if GroupNo=0 then Result:=Result+'non-ref' else
                  Result:=Result+'ref. set';
                end;
    i2CogCat:      begin Flag:=False;
                  Result:=Result+'categ. ';
                end;
  end;

  if PropType=8 then Exit;
  if TGeneListType(RelTo)=i2CogCat then Result:=Result+COGs[GroupNo+1];

  if Flag then Result:=Result+IntToStr(GroupNo);
  case FreqType of
    1: Result:=Result+' (bg)';
    2: Result:=Result+' (ncl)';
    3: Result:=Result+' (eql)';
  end;
end;

function Freq2String(Prop: Integer):String;
var
  PropType, RelTo, GroupNo, FreqType: Byte;
  AFreq: TCodonFreq; AList: TGeneList;
  RB: Single;
  Flag: boolean;
begin
  Result:=''; //initialize
  Flag:=True;
  DecodeProp(Prop, PropType, RelTo, GroupNo, FreqType);

  case TGeneListType(RelTo) of
    i2All:      begin Flag:=False; Result:=Result+'All genes'; end;
    i2File:   Result:=Result+'Genefile ';
    i2Set:      Result:=Result+'Custom set ';
    i2Cluster:  Result:=Result+'Cluster ';
    i2Bin:      Result:=Result+'Bin ';
    i2UserFreq: Result:=Result+'Freq table ';
    i2Ref:      begin Flag:=False;
                  if GroupNo=0 then Result:=Result+'Non-reference' else
                    Result:=Result+'Reference set';
                end;
    i2CogCat:      begin Flag:=False;
                  Result:=Result+'Category ';
                end;
  end;

  if TGeneListType(RelTo)=i2CogCat then Result:=Result+COGs[GroupNo+1];
  if Flag then Result:=Result+IntToStr(GroupNo);

  case FreqType of
    1: Result:=Result+' (bg)';
    2: Result:=Result+' (ncl)';
    3: Result:=Result+' (eql)';
  end;
end;

function Group2String(Prop: Integer): string;
var
  PropType, RelTo, GroupNo, FreqType: Byte;
  Flag: boolean;
begin
  Result:=''; //initialize
  Flag:=True;
  DecodeProp(Prop, PropType, RelTo, GroupNo, FreqType);
                                                           
  case TGeneListType(RelTo) of
    i2All:      begin Flag:=False; Result:=Result+'All genes'; end;
    i2File:   Result:=Result+'Genefile ';
    i2Set:      Result:=Result+'Custom set ';
    i2Cluster:  Result:=Result+'Cluster ';
    i2Bin:      Result:=Result+'Bin ';
    i2UserFreq: Result:=Result+'ERROR: FreqTable not a group!';
    i2Ref:      begin Flag:=False;
                  if GroupNo=0 then Result:=Result+'Non-reference' else
                    Result:=Result+'Reference set';
                end;
    i2CogCat:      begin Flag:=False;
                  Result:=Result+'Category ';
                end;
  end;

  if TGeneListType(RelTo)=i2CogCat then Result:=Result+COGs[GroupNo+1];
  if Flag then Result:=Result+IntToStr(GroupNo);
end;

end.
