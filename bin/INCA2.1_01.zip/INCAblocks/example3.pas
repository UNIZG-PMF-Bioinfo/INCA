// *****************************************************************************
// INCAblocks 2.1, release date 13-Feb-2006
// Maintained by: Fran Supek <fran.supek[at]gmail.com>
// INCAblocks may be copied and modified freely, but give credit where it's due
// Full version of INCA software can be found at http://bioinfo.hr/inca
// *****************************************************************************

// *****************************************************************************
// Example 3: Load the Shewanella oneidensis chromosome and plasmid, form a
// reference set as above. Create 2 custom sets; to Set 1 move the reference set
// genes and other highly expressed genes (MELP>x). To Set 2 move the
// horizontally transferred genes, where MILC(gene|non-Set1)>y. Output to the
// screen percentage of highly expressed (Set 1) and horizontally transferred
// (Set 2) genes on the chromosome and the plasmid. Allow x and y to be
// specified via command line parameters, e.g. "example3 0.9 0.7"
// The Shewanella oneidensis genome can be found at:
// ftp://ftp.ncbi.nih.gov/genomes/Bacteria/Shewanella_oneidensis
// *****************************************************************************

program INCAblocks_example3;

{$APPTYPE CONSOLE}

uses
  SysUtils, Classes, Math, i2code, i2genes, i2files;

var
  n: integer;
  Chromosome, Plasmid: TGeneList;
  HighExpr, Horizontal, Unassigned: TGeneList;
  HEcutoff, HORcutoff: Real;
  cnt: array [0..2] of integer;
  temp: Real;
  
begin

  if ParamCount<>2 then begin
    WriteLn('HELP: Please specify two numeric parameters');
    WriteLn('First is the MELP cutoff value for highly expressed genes');
    WriteLn('Second is the MILC cutoff value for horizontally transfered' +
      ' genes');
    WriteLn('Try typing eg: "example3 0.8 0.7"');
    Exit;  
  end; 
  
  HEcutoff := StrToFloat(ParamStr(1));
  HORcutoff := StrToFloat(ParamStr(2));
  
  INCAblocksInit;

  //now we'll create separate TGeneLists for the chromosome and the plasmid
  //we will store them into local variables for easy access
  Chromosome := TGeneList.Create(i2File); Plasmid := TGeneList.Create(i2File);
  
  Write('Please wait, parsing files... ');
      
  ParseFFN(Chromosome, '../genomes/NC_004347.ffn', nil, 100, 1, False);
  ParsePTT(Chromosome, '../genomes/NC_004347.ptt', nil, 100);  
  ParseFFN(Plasmid, '../genomes/NC_004349.ffn', nil, 100, 1, False);
  ParsePTT(Plasmid, '../genomes/NC_004349.ptt', nil, 100);  
    
  WriteLn('Files loaded.'); 
  
  for n:=0 to AllGenes.Count-1 do
    //check if the name of the gene starts with 'rps' or 'rpl'
    if (Pos('rps', AllGenes[n].Name)=1) or (Pos('rpl', AllGenes[n].Name)=1) then 
      RefSet.Add(AllGenes[n]); //this will automatically remove it from NonRef

      
  (* IMPORTANT! after moving genes from one list to another, you have to make a
  call to the Calculate procedure of the TGeneList objects you modified;
  see example2 for explanation. *)
      
  AllGenes.Calculate;    
  RefSet.Calculate;
          
  HighExpr := TGeneList.Create(i2Set); // =MetaLists[i2Set].Items[1]
  Horizontal := TGeneList.Create(i2Set); // =MetaLists[i2Set].Items[2]   
  Unassigned := MetaLists[i2Set].Items[0]; // this one exists by default
     
  for n:=0 to AllGenes.Count-1 do begin
    temp := AllGenes[n].MELP( AllGenes.Stats.CodonFreq, RefSet.Stats.CodonFreq );
    if (temp > HEcutoff) then HighExpr.Add( AllGenes[n] );
  end;    
  HighExpr.Calculate; //this isn't really needed as we don't need its freqs
  
  Unassigned.Calculate; //...but this IS necessary
  for n:=Unassigned.Count-1 downto 0 do begin
    temp := Unassigned[n].MILC( Unassigned.Stats.CodonFreq );
    if (temp > HORcutoff) then Horizontal.Add( Unassigned[n] );    
  end;    
  
  //Counts are always exact regardless of the use/disuse of TGeneList.Calculate
    
  WriteLn(''); 
  
  for n:=0 to 2 do cnt[n]:=0; //initialize counters
  
  for n:=0 to Chromosome.Count-1 do
    inc( cnt[ Chromosome[n].Member[i2Set] ] );

  WriteLn( 'In the chromosome there is exactly ' 
    + FloatToStrF( cnt[1] / Chromosome.Count * 100, ffFixed, 7, 2) 
    + '% highly expressed genes and '
    + FloatToStrF( cnt[2] / Chromosome.Count * 100, ffFixed, 7, 2) 
    + '% horizontally transfered genes (of '
    + IntToStr(Chromosome.Count) + ')' );

  for n:=0 to 2 do cnt[n]:=0; //initialize counters
  
  for n:=0 to Plasmid.Count-1 do
    inc( cnt[ Plasmid[n].Member[i2Set] ] );

  WriteLn('In the plasmid there is exactly ' 
    + FloatToStrF( cnt[1] / Plasmid.Count * 100, ffFixed, 7, 2) 
    + '% highly expressed genes and '
    + FloatToStrF( cnt[2] / Plasmid.Count * 100, ffFixed, 7, 2) 
    + '% horizontally transfered genes (of '
    + IntToStr(Plasmid.Count) + ')' );
    
end.

